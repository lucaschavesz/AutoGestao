/*
    Correção do cadastro de clientes - AutoGestão
    Execute no banco AutoGestao pelo SQL Server Management Studio.

    A restrição CK_Usuario_Perfil atualmente não permite o perfil 'Cliente'.
    Esta alteração mantém os perfis existentes e acrescenta 'Cliente'.
*/
USE AutoGestao;
GO

IF EXISTS (
    SELECT 1
    FROM sys.check_constraints
    WHERE name = 'CK_Usuario_Perfil'
      AND parent_object_id = OBJECT_ID('dbo.Usuario')
)
BEGIN
    ALTER TABLE dbo.Usuario DROP CONSTRAINT CK_Usuario_Perfil;
END;
GO

ALTER TABLE dbo.Usuario WITH CHECK
ADD CONSTRAINT CK_Usuario_Perfil
CHECK (perfil IN ('Administrador', 'Funcionario', 'Cliente'));
GO

-- Confirma a definição atual da restrição.
SELECT name, definition
FROM sys.check_constraints
WHERE parent_object_id = OBJECT_ID('dbo.Usuario')
  AND name = 'CK_Usuario_Perfil';
GO
