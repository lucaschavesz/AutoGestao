USE [master];
GO

IF DB_ID(N'AutoGestao') IS NULL
BEGIN
    CREATE DATABASE [AutoGestao];
END;
GO

USE [AutoGestao];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

-- =============================================
-- TABELAS
-- =============================================
CREATE TABLE [dbo].[Carro] (
    [id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [marca] VARCHAR(80) NOT NULL,
    [modelo] VARCHAR(120) NOT NULL,
    [ano] INT NOT NULL,
    [versao] VARCHAR(100) NULL,
    [quilometragem] INT NOT NULL,
    [cambio] VARCHAR(30) NULL,
    [combustivel] VARCHAR(30) NULL,
    [motorizacao] VARCHAR(30) NULL,
    [potencia] VARCHAR(30) NULL,
    [codigo_marca_fipe] VARCHAR(20) NULL,
    [codigo_modelo_fipe] VARCHAR(20) NULL,
    [codigo_ano_fipe] VARCHAR(20) NULL,
    [codigo_fipe] VARCHAR(20) NULL,
    [valor_fipe] DECIMAL(12,2) NULL,
    [mes_referencia_fipe] VARCHAR(40) NULL,
    [valor_venda] DECIMAL(12,2) NOT NULL,
    [documentacao] BIT NOT NULL,
    [garantia_revisao] VARCHAR(200) NULL,
    [leilao] BIT NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    [data_cadastro] DATETIME2(7) NOT NULL
);
GO

CREATE TABLE [dbo].[CarroFoto] (
    [id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [carro_id] INT NOT NULL,
    [caminho_imagem] VARCHAR(255) NOT NULL,
    [foto_principal] BIT NOT NULL
);
GO

CREATE TABLE [dbo].[Pessoa] (
    [id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [tipo_pessoa] VARCHAR(20) NOT NULL,
    [nome] VARCHAR(100) NOT NULL,
    [cpf] VARCHAR(14) NOT NULL UNIQUE,
    [telefone] VARCHAR(20) NULL,
    [email] VARCHAR(100) NULL,
    [data_nascimento] DATE NULL,
    [cep] VARCHAR(10) NULL,
    [rua] VARCHAR(120) NULL,
    [bairro] VARCHAR(80) NULL,
    [cidade] VARCHAR(80) NULL,
    [data_cadastro] DATETIME2(7) NULL,
    [cargo] VARCHAR(50) NULL,
    [salario] DECIMAL(12,2) NULL,
    [data_contratacao] DATE NULL,
    [status_funcionario] BIT NULL
);
GO

CREATE TABLE [dbo].[Usuario] (
    [id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [funcionario_id] INT NOT NULL UNIQUE,
    [login] VARCHAR(50) NOT NULL UNIQUE,
    [senha_hash] VARCHAR(255) NOT NULL,
    [perfil] VARCHAR(20) NOT NULL,
    [ativo] BIT NOT NULL,
    [data_criacao] DATETIME2(7) NOT NULL
);
GO

CREATE TABLE [dbo].[Venda] (
    [id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [cliente_id] INT NOT NULL,
    [funcionario_id] INT NOT NULL,
    [carro_id] INT NOT NULL,
    [data_venda] DATETIME2(7) NOT NULL,
    [valor_venda] DECIMAL(12,2) NOT NULL,
    [desconto] DECIMAL(12,2) NOT NULL,
    [forma_pagamento] VARCHAR(30) NOT NULL,
    [qtd_parcelas] INT NOT NULL,
    [valor_entrada] DECIMAL(12,2) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO

CREATE TABLE [dbo].[Parcela] (
    [id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [venda_id] INT NOT NULL,
    [numero_parcela] INT NOT NULL,
    [valor] DECIMAL(12,2) NOT NULL,
    [data_vencimento] DATE NOT NULL,
    [data_pagamento] DATE NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [UQ_Parcela_Numero] UNIQUE NONCLUSTERED ([venda_id] ASC, [numero_parcela] ASC)
);
GO

-- =============================================
-- INDICES
-- =============================================
CREATE NONCLUSTERED INDEX [IX_Carro_Status] ON [dbo].[Carro] ([status] ASC);
GO
CREATE NONCLUSTERED INDEX [IX_CarroFoto_Carro] ON [dbo].[CarroFoto] ([carro_id] ASC);
GO
CREATE NONCLUSTERED INDEX [IX_Venda_Cliente] ON [dbo].[Venda] ([cliente_id] ASC);
GO
CREATE NONCLUSTERED INDEX [IX_Venda_Data] ON [dbo].[Venda] ([data_venda] ASC);
GO
CREATE NONCLUSTERED INDEX [IX_Venda_Funcionario] ON [dbo].[Venda] ([funcionario_id] ASC);
GO
CREATE UNIQUE NONCLUSTERED INDEX [UX_Venda_Carro_Ativo]
ON [dbo].[Venda] ([carro_id] ASC)
WHERE ([status] <> 'Cancelada');
GO

-- =============================================
-- DEFAULTS
-- =============================================
ALTER TABLE [dbo].[Carro] ADD DEFAULT ((1)) FOR [documentacao];
ALTER TABLE [dbo].[Carro] ADD DEFAULT ((0)) FOR [leilao];
ALTER TABLE [dbo].[Carro] ADD DEFAULT ('Disponivel') FOR [status];
ALTER TABLE [dbo].[Carro] ADD DEFAULT (GETDATE()) FOR [data_cadastro];

ALTER TABLE [dbo].[CarroFoto] ADD DEFAULT ((0)) FOR [foto_principal];
ALTER TABLE [dbo].[Parcela] ADD DEFAULT ('Pendente') FOR [status];

ALTER TABLE [dbo].[Usuario] ADD DEFAULT ((1)) FOR [ativo];
ALTER TABLE [dbo].[Usuario] ADD DEFAULT (GETDATE()) FOR [data_criacao];

ALTER TABLE [dbo].[Venda] ADD DEFAULT (GETDATE()) FOR [data_venda];
ALTER TABLE [dbo].[Venda] ADD DEFAULT ((0)) FOR [desconto];
ALTER TABLE [dbo].[Venda] ADD DEFAULT ((1)) FOR [qtd_parcelas];
ALTER TABLE [dbo].[Venda] ADD DEFAULT ((0)) FOR [valor_entrada];
ALTER TABLE [dbo].[Venda] ADD DEFAULT ('Pendente') FOR [status];
GO

-- =============================================
-- FOREIGN KEYS
-- =============================================
ALTER TABLE [dbo].[CarroFoto] WITH CHECK ADD CONSTRAINT [FK_CarroFoto_Carro]
    FOREIGN KEY ([carro_id]) REFERENCES [dbo].[Carro] ([id]) ON DELETE CASCADE;
GO
ALTER TABLE [dbo].[Parcela] WITH CHECK ADD CONSTRAINT [FK_Parcela_Venda]
    FOREIGN KEY ([venda_id]) REFERENCES [dbo].[Venda] ([id]) ON DELETE CASCADE;
GO
ALTER TABLE [dbo].[Usuario] WITH CHECK ADD CONSTRAINT [FK_Usuario_Funcionario]
    FOREIGN KEY ([funcionario_id]) REFERENCES [dbo].[Pessoa] ([id]);
GO
ALTER TABLE [dbo].[Venda] WITH CHECK ADD CONSTRAINT [FK_Venda_Carro]
    FOREIGN KEY ([carro_id]) REFERENCES [dbo].[Carro] ([id]);
GO
ALTER TABLE [dbo].[Venda] WITH CHECK ADD CONSTRAINT [FK_Venda_Cliente]
    FOREIGN KEY ([cliente_id]) REFERENCES [dbo].[Pessoa] ([id]);
GO
ALTER TABLE [dbo].[Venda] WITH CHECK ADD CONSTRAINT [FK_Venda_Funcionario]
    FOREIGN KEY ([funcionario_id]) REFERENCES [dbo].[Pessoa] ([id]);
GO

-- =============================================
-- CHECK CONSTRAINTS
-- =============================================
ALTER TABLE [dbo].[Carro] WITH CHECK ADD CONSTRAINT [CK_Carro_Ano]
    CHECK (([ano] >= (1900) AND [ano] <= (2100)));
ALTER TABLE [dbo].[Carro] WITH CHECK ADD CONSTRAINT [CK_Carro_Quilometragem]
    CHECK (([quilometragem] >= (0)));
ALTER TABLE [dbo].[Carro] WITH CHECK ADD CONSTRAINT [CK_Carro_Status]
    CHECK (([status] = 'Vendido' OR [status] = 'Reservado' OR [status] = 'Disponivel'));
ALTER TABLE [dbo].[Carro] WITH CHECK ADD CONSTRAINT [CK_Carro_Valor]
    CHECK (([valor_venda] >= (0)));
ALTER TABLE [dbo].[Carro] WITH CHECK ADD CONSTRAINT [CK_Carro_ValorFipe]
    CHECK (([valor_fipe] IS NULL OR [valor_fipe] >= (0)));

ALTER TABLE [dbo].[Parcela] WITH CHECK ADD CONSTRAINT [CK_Parcela_Status]
    CHECK (([status] = 'Atrasada' OR [status] = 'Paga' OR [status] = 'Pendente'));
ALTER TABLE [dbo].[Parcela] WITH CHECK ADD CONSTRAINT [CK_Parcela_Valor]
    CHECK (([valor] > (0)));

ALTER TABLE [dbo].[Pessoa] WITH CHECK ADD CONSTRAINT [CK_Pessoa_Funcionario]
    CHECK (([tipo_pessoa] = 'Cliente' OR ([cargo] IS NOT NULL AND [data_contratacao] IS NOT NULL AND [status_funcionario] IS NOT NULL)));
ALTER TABLE [dbo].[Pessoa] WITH CHECK ADD CONSTRAINT [CK_Pessoa_Tipo]
    CHECK (([tipo_pessoa] = 'Funcionario' OR [tipo_pessoa] = 'Cliente'));

ALTER TABLE [dbo].[Usuario] WITH CHECK ADD CONSTRAINT [CK_Usuario_Perfil]
    CHECK (([perfil] = 'Funcionario' OR [perfil] = 'Administrador'));

ALTER TABLE [dbo].[Venda] WITH CHECK ADD CONSTRAINT [CK_Venda_Desconto]
    CHECK (([desconto] >= (0) AND [desconto] <= [valor_venda]));
ALTER TABLE [dbo].[Venda] WITH CHECK ADD CONSTRAINT [CK_Venda_Entrada]
    CHECK (([valor_entrada] >= (0)));
ALTER TABLE [dbo].[Venda] WITH CHECK ADD CONSTRAINT [CK_Venda_Parcelas]
    CHECK (([qtd_parcelas] >= (1)));
ALTER TABLE [dbo].[Venda] WITH CHECK ADD CONSTRAINT [CK_Venda_Status]
    CHECK (([status] = 'Cancelada' OR [status] = 'Concluida' OR [status] = 'Pendente'));
ALTER TABLE [dbo].[Venda] WITH CHECK ADD CONSTRAINT [CK_Venda_Valor]
    CHECK (([valor_venda] >= (0)));
GO

-- =============================================
-- STORED PROCEDURES
-- =============================================
CREATE PROCEDURE [dbo].[spAtualizaStatusCarro]
(
    @carro_id INT,
    @status VARCHAR(20)
)
AS
BEGIN
    UPDATE Carro SET status = @status WHERE id = @carro_id;
END;
GO

CREATE PROCEDURE [dbo].[spConsulta]
(
    @id INT,
    @tabela VARCHAR(MAX)
)
AS
BEGIN
    DECLARE @sql VARCHAR(MAX);
    SET @sql = 'SELECT * FROM ' + @tabela + ' WHERE id = ' + CAST(@id AS VARCHAR(MAX));
    EXEC(@sql);
END;
GO

CREATE PROCEDURE [dbo].[spConsultaAvancadaCarros]
(
    @modelo VARCHAR(120),
    @marca VARCHAR(80),
    @status VARCHAR(20),
    @dataInicial DATETIME2,
    @dataFinal DATETIME2
)
AS
BEGIN
    SELECT c.*,
           (SELECT TOP 1 cf.caminho_imagem FROM CarroFoto cf WHERE cf.carro_id = c.id ORDER BY cf.foto_principal DESC, cf.id ASC) AS foto_principal_caminho
    FROM Carro c
    WHERE c.modelo LIKE '%' + @modelo + '%'
      AND (@marca = '' OR c.marca = @marca)
      AND (@status = '' OR c.status = @status)
      AND c.data_cadastro BETWEEN @dataInicial AND @dataFinal
    ORDER BY c.id DESC;
END;
GO

CREATE PROCEDURE [dbo].[spConsultaAvancadaVendas]
(
    @cliente_nome VARCHAR(100),
    @funcionario_id INT,
    @status VARCHAR(20),
    @dataInicial DATETIME2,
    @dataFinal DATETIME2
)
AS
BEGIN
    SELECT v.id, v.data_venda, v.valor_venda, v.desconto, v.forma_pagamento, v.qtd_parcelas, v.valor_entrada, v.status,
           c.nome AS cliente_nome, c.cpf AS cliente_cpf,
           f.nome AS funcionario_nome,
           ca.marca AS carro_marca, ca.modelo AS carro_modelo, ca.ano AS carro_ano
    FROM Venda v
    INNER JOIN Pessoa c ON v.cliente_id = c.id
    INNER JOIN Pessoa f ON v.funcionario_id = f.id
    INNER JOIN Carro ca ON v.carro_id = ca.id
    WHERE c.nome LIKE '%' + @cliente_nome + '%'
      AND (@funcionario_id = 0 OR v.funcionario_id = @funcionario_id)
      AND (@status = '' OR v.status = @status)
      AND v.data_venda BETWEEN @dataInicial AND @dataFinal
    ORDER BY v.data_venda DESC;
END;
GO

CREATE PROCEDURE [dbo].[spDelete]
(
    @id INT,
    @tabela VARCHAR(MAX)
)
AS
BEGIN
    DECLARE @sql VARCHAR(MAX);
    SET @sql = 'DELETE FROM ' + @tabela + ' WHERE id = ' + CAST(@id AS VARCHAR(MAX));
    EXEC(@sql);
END;
GO

CREATE PROCEDURE [dbo].[spInsert_Carro]
(
    @id INT,
    @marca VARCHAR(80),
    @modelo VARCHAR(120),
    @ano INT,
    @versao VARCHAR(100),
    @quilometragem INT,
    @cambio VARCHAR(30),
    @combustivel VARCHAR(30),
    @motorizacao VARCHAR(30),
    @potencia VARCHAR(30),
    @codigo_marca_fipe VARCHAR(20),
    @codigo_modelo_fipe VARCHAR(20),
    @codigo_ano_fipe VARCHAR(20),
    @codigo_fipe VARCHAR(20),
    @valor_fipe DECIMAL(12,2),
    @mes_referencia_fipe VARCHAR(40),
    @valor_venda DECIMAL(12,2),
    @documentacao BIT,
    @garantia_revisao VARCHAR(200),
    @leilao BIT,
    @status VARCHAR(20),
    @data_cadastro DATETIME2
)
AS
BEGIN
    INSERT INTO Carro
    (marca, modelo, ano, versao, quilometragem, cambio, combustivel, motorizacao, potencia,
     codigo_marca_fipe, codigo_modelo_fipe, codigo_ano_fipe, codigo_fipe, valor_fipe, mes_referencia_fipe,
     valor_venda, documentacao, garantia_revisao, leilao, status, data_cadastro)
    VALUES
    (@marca, @modelo, @ano, @versao, @quilometragem, @cambio, @combustivel, @motorizacao, @potencia,
     @codigo_marca_fipe, @codigo_modelo_fipe, @codigo_ano_fipe, @codigo_fipe, @valor_fipe, @mes_referencia_fipe,
     @valor_venda, @documentacao, @garantia_revisao, @leilao, @status, @data_cadastro);
END;
GO

CREATE PROCEDURE [dbo].[spInsert_CarroFoto]
(
    @id INT,
    @carro_id INT,
    @caminho_imagem VARCHAR(255),
    @foto_principal BIT
)
AS
BEGIN
    INSERT INTO CarroFoto (carro_id, caminho_imagem, foto_principal)
    VALUES (@carro_id, @caminho_imagem, @foto_principal);
END;
GO

CREATE PROCEDURE [dbo].[spInsert_Parcela]
(
    @id INT,
    @venda_id INT,
    @numero_parcela INT,
    @valor DECIMAL(12,2),
    @data_vencimento DATE,
    @data_pagamento DATE,
    @status VARCHAR(20)
)
AS
BEGIN
    INSERT INTO Parcela (venda_id, numero_parcela, valor, data_vencimento, data_pagamento, status)
    VALUES (@venda_id, @numero_parcela, @valor, @data_vencimento, @data_pagamento, @status);
END;
GO

CREATE PROCEDURE [dbo].[spInsert_Pessoa_Cliente]
(
    @id INT,
    @nome VARCHAR(100),
    @cpf VARCHAR(14),
    @telefone VARCHAR(20),
    @email VARCHAR(100),
    @data_nascimento DATE,
    @cep VARCHAR(10),
    @rua VARCHAR(120),
    @bairro VARCHAR(80),
    @cidade VARCHAR(80),
    @data_cadastro DATETIME2
)
AS
BEGIN
    INSERT INTO Pessoa
    (tipo_pessoa, nome, cpf, telefone, email, data_nascimento, cep, rua, bairro, cidade, data_cadastro)
    VALUES
    ('Cliente', @nome, @cpf, @telefone, @email, @data_nascimento, @cep, @rua, @bairro, @cidade, @data_cadastro);
END;
GO

CREATE PROCEDURE [dbo].[spInsert_Pessoa_Funcionario]
(
    @id INT,
    @nome VARCHAR(100),
    @cpf VARCHAR(14),
    @telefone VARCHAR(20),
    @email VARCHAR(100),
    @data_nascimento DATE,
    @cep VARCHAR(10),
    @rua VARCHAR(120),
    @bairro VARCHAR(80),
    @cidade VARCHAR(80),
    @cargo VARCHAR(50),
    @salario DECIMAL(12,2),
    @data_contratacao DATE,
    @status_funcionario BIT
)
AS
BEGIN
    INSERT INTO Pessoa
    (tipo_pessoa, nome, cpf, telefone, email, data_nascimento, cep, rua, bairro, cidade, cargo, salario, data_contratacao, status_funcionario)
    VALUES
    ('Funcionario', @nome, @cpf, @telefone, @email, @data_nascimento, @cep, @rua, @bairro, @cidade, @cargo, @salario, @data_contratacao, @status_funcionario);
END;
GO

CREATE PROCEDURE [dbo].[spInsert_Usuario]
(
    @id INT = 0,
    @funcionario_id INT,
    @login VARCHAR(50),
    @senha_hash VARCHAR(255),
    @perfil VARCHAR(20),
    @ativo BIT
)
AS
BEGIN
    INSERT INTO Usuario
    (funcionario_id, login, senha_hash, perfil, ativo, data_criacao)
    VALUES
    (@funcionario_id, @login, @senha_hash, @perfil, @ativo, GETDATE());
END;
GO

CREATE PROCEDURE [dbo].[spInsert_Venda]
(
    @id INT,
    @cliente_id INT,
    @funcionario_id INT,
    @carro_id INT,
    @data_venda DATETIME2,
    @valor_venda DECIMAL(12,2),
    @desconto DECIMAL(12,2),
    @forma_pagamento VARCHAR(30),
    @qtd_parcelas INT,
    @valor_entrada DECIMAL(12,2),
    @status VARCHAR(20)
)
AS
BEGIN
    INSERT INTO Venda
    (cliente_id, funcionario_id, carro_id, data_venda, valor_venda, desconto, forma_pagamento, qtd_parcelas, valor_entrada, status)
    VALUES
    (@cliente_id, @funcionario_id, @carro_id, @data_venda, @valor_venda, @desconto, @forma_pagamento, @qtd_parcelas, @valor_entrada, @status);
END;
GO

CREATE PROCEDURE [dbo].[spListagem]
(
    @tabela VARCHAR(MAX),
    @ordem VARCHAR(MAX)
)
AS
BEGIN
    EXEC('SELECT * FROM ' + @tabela + ' ORDER BY ' + @ordem);
END;
GO

CREATE PROCEDURE [dbo].[spListagemCarros]
AS
BEGIN
    SELECT c.*,
           (SELECT TOP 1 cf.caminho_imagem FROM CarroFoto cf WHERE cf.carro_id = c.id ORDER BY cf.foto_principal DESC, cf.id ASC) AS foto_principal_caminho
    FROM Carro c
    ORDER BY c.id DESC;
END;
GO

CREATE PROCEDURE [dbo].[spListagemClientes]
(
    @tabela VARCHAR(MAX) = 'Pessoa',
    @ordem VARCHAR(MAX) = 'nome'
)
AS
BEGIN
    SELECT *
    FROM Pessoa
    WHERE tipo_pessoa = 'Cliente'
    ORDER BY nome;
END;
GO

CREATE PROCEDURE [dbo].[spListagemFuncionarios]
(
    @tabela VARCHAR(MAX) = 'Pessoa',
    @ordem VARCHAR(MAX) = 'nome'
)
AS
BEGIN
    SELECT *
    FROM Pessoa
    WHERE tipo_pessoa = 'Funcionario'
    ORDER BY nome;
END;
GO

CREATE PROCEDURE [dbo].[spListagemParcelas]
(
    @vendaId INT = 0
)
AS
BEGIN
    SELECT p.id,
           p.venda_id,
           p.numero_parcela,
           p.valor,
           p.data_vencimento,
           p.data_pagamento,
           p.status,
           c.nome AS cliente_nome
    FROM Parcela p
    INNER JOIN Venda v ON p.venda_id = v.id
    INNER JOIN Pessoa c ON v.cliente_id = c.id
    WHERE (@vendaId = 0 OR p.venda_id = @vendaId)
    ORDER BY p.venda_id DESC, p.numero_parcela ASC;
END;
GO

CREATE PROCEDURE [dbo].[spListagemVendas]
(
    @tabela VARCHAR(MAX) = 'Venda',
    @ordem VARCHAR(MAX) = 'v.data_venda DESC'
)
AS
BEGIN
    SELECT v.id,
           v.cliente_id,
           v.funcionario_id,
           v.carro_id,
           v.data_venda,
           v.valor_venda,
           v.desconto,
           v.forma_pagamento,
           v.qtd_parcelas,
           v.valor_entrada,
           v.status,
           c.nome AS cliente_nome,
           f.nome AS funcionario_nome,
           ca.marca AS carro_marca,
           ca.modelo AS carro_modelo,
           ca.ano AS carro_ano
    FROM Venda v
    INNER JOIN Pessoa c ON v.cliente_id = c.id
    INNER JOIN Pessoa f ON v.funcionario_id = f.id
    INNER JOIN Carro ca ON v.carro_id = ca.id
    ORDER BY v.data_venda DESC;
END;
GO

CREATE PROCEDURE [dbo].[spProximoId]
(
    @tabela VARCHAR(MAX)
)
AS
BEGIN
    EXEC('SELECT ISNULL(MAX(id) + 1, 1) AS MAIOR FROM ' + @tabela);
END;
GO

CREATE PROCEDURE [dbo].[spUpdate_Carro]
(
    @id INT,
    @marca VARCHAR(80),
    @modelo VARCHAR(120),
    @ano INT,
    @versao VARCHAR(100),
    @quilometragem INT,
    @cambio VARCHAR(30),
    @combustivel VARCHAR(30),
    @motorizacao VARCHAR(30),
    @potencia VARCHAR(30),
    @codigo_marca_fipe VARCHAR(20),
    @codigo_modelo_fipe VARCHAR(20),
    @codigo_ano_fipe VARCHAR(20),
    @codigo_fipe VARCHAR(20),
    @valor_fipe DECIMAL(12,2),
    @mes_referencia_fipe VARCHAR(40),
    @valor_venda DECIMAL(12,2),
    @documentacao BIT,
    @garantia_revisao VARCHAR(200),
    @leilao BIT,
    @status VARCHAR(20),
    @data_cadastro DATETIME2
)
AS
BEGIN
    UPDATE Carro SET
        marca = @marca,
        modelo = @modelo,
        ano = @ano,
        versao = @versao,
        quilometragem = @quilometragem,
        cambio = @cambio,
        combustivel = @combustivel,
        motorizacao = @motorizacao,
        potencia = @potencia,
        codigo_marca_fipe = @codigo_marca_fipe,
        codigo_modelo_fipe = @codigo_modelo_fipe,
        codigo_ano_fipe = @codigo_ano_fipe,
        codigo_fipe = @codigo_fipe,
        valor_fipe = @valor_fipe,
        mes_referencia_fipe = @mes_referencia_fipe,
        valor_venda = @valor_venda,
        documentacao = @documentacao,
        garantia_revisao = @garantia_revisao,
        leilao = @leilao,
        status = @status
    WHERE id = @id;
END;
GO

CREATE PROCEDURE [dbo].[spUpdate_Pessoa_Cliente]
(
    @id INT,
    @nome VARCHAR(100),
    @cpf VARCHAR(14),
    @telefone VARCHAR(20),
    @email VARCHAR(100),
    @data_nascimento DATE,
    @cep VARCHAR(10),
    @rua VARCHAR(120),
    @bairro VARCHAR(80),
    @cidade VARCHAR(80),
    @data_cadastro DATETIME2
)
AS
BEGIN
    UPDATE Pessoa SET
        nome = @nome,
        cpf = @cpf,
        telefone = @telefone,
        email = @email,
        data_nascimento = @data_nascimento,
        cep = @cep,
        rua = @rua,
        bairro = @bairro,
        cidade = @cidade,
        data_cadastro = @data_cadastro
    WHERE id = @id AND tipo_pessoa = 'Cliente';
END;
GO

CREATE PROCEDURE [dbo].[spUpdate_Pessoa_Funcionario]
(
    @id INT,
    @nome VARCHAR(100),
    @cpf VARCHAR(14),
    @telefone VARCHAR(20),
    @email VARCHAR(100),
    @data_nascimento DATE,
    @cep VARCHAR(10),
    @rua VARCHAR(120),
    @bairro VARCHAR(80),
    @cidade VARCHAR(80),
    @cargo VARCHAR(50),
    @salario DECIMAL(12,2),
    @data_contratacao DATE,
    @status_funcionario BIT
)
AS
BEGIN
    UPDATE Pessoa SET
        nome = @nome,
        cpf = @cpf,
        telefone = @telefone,
        email = @email,
        data_nascimento = @data_nascimento,
        cep = @cep,
        rua = @rua,
        bairro = @bairro,
        cidade = @cidade,
        cargo = @cargo,
        salario = @salario,
        data_contratacao = @data_contratacao,
        status_funcionario = @status_funcionario
    WHERE id = @id AND tipo_pessoa = 'Funcionario';
END;
GO