﻿using Microsoft.AspNetCore.Mvc;

namespace AutoGestao.Controllers
{
    public class SobreController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}