﻿using AutoGestao.DAO;
using AutoGestao.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace AutoGestao.Controllers
{
    public class ParcelaController : PadraoController<ParcelaViewModel>
    {
        public ParcelaController()
        {
            DAO = new ParcelaDAO();
            GeraProximoId = true;
        }

        [HttpGet]
        public new IActionResult Index(int vendaId = 0)
        {
            try
            {
                ParcelaDAO dao = new ParcelaDAO();
                List<ParcelaViewModel> lista = dao.ListagemPorVenda(vendaId);
                ViewBag.VendaIdFiltro = vendaId;
                return View("Index", lista);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
    }
}
