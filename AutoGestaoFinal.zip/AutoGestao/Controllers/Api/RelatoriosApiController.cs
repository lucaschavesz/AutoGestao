using System;
using System.Data;
using System.Globalization;
using System.Linq;
using AutoGestao.DAO;
using AutoGestao.Models.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AutoGestao.Controllers.Api
{
    /// <summary>
    /// APIs de consulta consolidada sobre as vendas. Somente leitura (GET), resposta em JSON.
    /// Exigem sessão autenticada (faça POST /Login/FazLogin antes — o navegador/cliente guarda o cookie de sessão).
    /// </summary>
    [ApiController]
    [Route("api/relatorios")]
    [Produces("application/json")]
    public class RelatoriosApiController : ControllerBase
    {
        private readonly RelatorioDAO _dao = new RelatorioDAO();

        private bool NaoAutenticado()
        {
            return !HelperController.VerificaUserLogado(HttpContext.Session);
        }

        private IActionResult Erro(int status, string msg)
        {
            return StatusCode(status, new { erro = true, mensagem = msg });
        }

        /// <summary>
        /// Resumo consolidado: totais de vendas, divisão por forma de pagamento,
        /// situação do estoque e carteira de parcelas.
        /// </summary>
        /// <param name="dataInicial">Data inicial opcional (ex.: 2026-01-01). Se omitida junto com dataFinal, considera todo o histórico.</param>
        /// <param name="dataFinal">Data final opcional (ex.: 2026-12-31). Não pode ser anterior a dataInicial.</param>
        /// <returns>Objeto consolidado com período, totais de vendas, formas de pagamento, estoque e parcelas.</returns>
        [HttpGet("resumo-vendas")]
        [ProducesResponseType(typeof(ResumoVendasResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ResumoVendas([FromQuery] DateTime? dataInicial, [FromQuery] DateTime? dataFinal)
        {
            if (NaoAutenticado())
                return Erro(401, "Não autenticado. Faça login em /Login/FazLogin antes de chamar a API.");
            if (dataInicial.HasValue && dataFinal.HasValue && dataInicial.Value.Date > dataFinal.Value.Date)
                return Erro(400, "dataInicial não pode ser maior que dataFinal.");

            try
            {
                var resposta = new ResumoVendasResponse
                {
                    Periodo = new PeriodoDto
                    {
                        DataInicial = dataInicial.HasValue ? (DateTime?)dataInicial.Value.Date : null,
                        DataFinal = dataFinal.HasValue ? (DateTime?)dataFinal.Value.Date : null
                    },
                    Vendas = _dao.TotaisVendas(dataInicial, dataFinal),
                    PorFormaPagamento = _dao.PorFormaPagamento(dataInicial, dataFinal),
                    Estoque = _dao.Estoque(),
                    Parcelas = _dao.CarteiraParcelas()
                };
                return Ok(resposta);
            }
            catch (Exception e)
            {
                return Erro(500, e.Message);
            }
        }

        /// <summary>
        /// Desempenho anual: série mensal (12 meses), ranking de vendedores e top 5 marcas.
        /// </summary>
        /// <param name="ano">Ano de consulta entre 2000 e 2100. Se omitido, usa o ano atual.</param>
        /// <returns>Série mensal com ticket médio, ranking de vendedores e marcas mais vendidas no ano.</returns>
        [HttpGet("desempenho")]
        [ProducesResponseType(typeof(DesempenhoResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Desempenho([FromQuery] int? ano)
        {
            if (NaoAutenticado())
                return Erro(401, "Não autenticado. Faça login em /Login/FazLogin antes de chamar a API.");

            int anoConsulta = ano ?? DateTime.Today.Year;
            if (anoConsulta < 2000 || anoConsulta > 2100)
                return Erro(400, "ano deve estar entre 2000 e 2100.");

            try
            {
                var cultura = new CultureInfo("pt-BR");
                var resposta = new DesempenhoResponse { Ano = anoConsulta };

                // Série mensal sempre com 12 posições (meses sem venda vêm zerados)
                var porMes = _dao.VendasPorMes(anoConsulta);
                for (int m = 1; m <= 12; m++)
                {
                    var linha = porMes.Rows.Cast<DataRow>().FirstOrDefault(r => Convert.ToInt32(r["mes"]) == m);
                    int qtd = linha == null ? 0 : Convert.ToInt32(linha["qtd"]);
                    decimal liquido = linha == null ? 0m : Convert.ToDecimal(linha["liquido"]);
                    string nome = cultura.DateTimeFormat.GetMonthName(m);
                    resposta.PorMes.Add(new VendaMensalDto
                    {
                        Mes = m,
                        NomeMes = char.ToUpper(nome[0]) + nome.Substring(1),
                        Quantidade = qtd,
                        FaturamentoLiquido = liquido,
                        TicketMedio = qtd > 0 ? Math.Round(liquido / qtd, 2) : 0m
                    });
                }
                resposta.TotalVendasAno = resposta.PorMes.Sum(x => x.Quantidade);
                resposta.FaturamentoLiquidoAno = resposta.PorMes.Sum(x => x.FaturamentoLiquido);

                var melhor = resposta.PorMes.OrderByDescending(x => x.FaturamentoLiquido).First();
                if (melhor.FaturamentoLiquido > 0)
                    resposta.MelhorMes = new MelhorMesDto { Mes = melhor.Mes, NomeMes = melhor.NomeMes, FaturamentoLiquido = melhor.FaturamentoLiquido };

                // Ranking de vendedores
                int posicao = 1;
                foreach (DataRow r in _dao.RankingVendedores(anoConsulta).Rows)
                {
                    decimal liquido = Convert.ToDecimal(r["liquido"]);
                    resposta.RankingVendedores.Add(new RankingVendedorDto
                    {
                        Posicao = posicao++,
                        FuncionarioId = Convert.ToInt32(r["funcionario_id"]),
                        Nome = r["nome"].ToString(),
                        Quantidade = Convert.ToInt32(r["qtd"]),
                        FaturamentoLiquido = liquido,
                        ParticipacaoPercentual = resposta.FaturamentoLiquidoAno > 0
                            ? Math.Round(liquido / resposta.FaturamentoLiquidoAno * 100m, 2) : 0m
                    });
                }

                // Top 5 marcas mais vendidas
                foreach (DataRow r in _dao.TopMarcas(anoConsulta, 5).Rows)
                {
                    resposta.TopMarcas.Add(new RankingMarcaDto
                    {
                        Marca = r["marca"].ToString(),
                        Quantidade = Convert.ToInt32(r["qtd"]),
                        FaturamentoLiquido = Convert.ToDecimal(r["liquido"])
                    });
                }

                return Ok(resposta);
            }
            catch (Exception e)
            {
                return Erro(500, e.Message);
            }
        }
    }
}