﻿using Microsoft.AspNetCore.Http;

namespace AutoGestao.Controllers
{
    public class HelperController
    {
        public static bool VerificaUserLogado(ISession session)
        {
            string perfil = session.GetString("UsuarioPerfil");
            return session.GetString("Logado") == "true" &&
                   (perfil == "Administrador" || perfil == "Funcionario");
        }

        public static bool VerificaClienteLogado(ISession session)
        {
            return session.GetString("Logado") == "true" &&
                   session.GetString("UsuarioPerfil") == "Cliente";
        }
    }
}
