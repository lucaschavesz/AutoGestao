﻿using AutoGestao.DAO;
using AutoGestao.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Linq;
using System.Transactions;

namespace AutoGestao.Controllers
{
    public class VendaController : PadraoController<VendaViewModel>
    {
        public VendaController()
        {
            DAO = new VendaDAO();
            GeraProximoId = true;
        }

        protected override void PreencheDadosParaView(string Operacao, VendaViewModel model)
        {
            base.PreencheDadosParaView(Operacao, model);
            model.DataVenda = DateTime.Now;
            if (model.QtdParcelas <= 0) model.QtdParcelas = 1;

            ClienteDAO clienteDao = new ClienteDAO();
            ViewBag.Clientes = clienteDao.Listagem()
                .Select(c => new SelectListItem($"{c.Nome} ({c.Cpf})", c.Id.ToString())).ToList();

            CarroDAO carroDao = new CarroDAO();
            var disponiveis = carroDao.Listagem().Where(c => c.Status == "Disponivel").ToList();
            ViewBag.CarrosDisponiveis = disponiveis
                .Select(c => new SelectListItem($"{c.Marca} {c.Modelo} {c.Ano} - R$ {c.ValorVenda:0.00}", c.Id.ToString())).ToList();

            // Mapa id -> preço, usado pela tela para preencher o valor da venda e calcular o resumo.
            // "numero" é invariante (para cálculo em JS); "texto" usa a cultura atual (para preencher o input).
            ViewBag.PrecosCarrosJson = System.Text.Json.JsonSerializer.Serialize(
                disponiveis.ToDictionary(c => c.Id.ToString(), c => new { numero = c.ValorVenda, texto = c.ValorVenda.ToString("0.00") }));
        }

        public IActionResult EfetuarVenda(VendaViewModel venda)
        {
            try
            {
                CarroDAO carroDao = new CarroDAO();
                var carro = carroDao.Consulta(venda.CarroId);
                if (carro == null || carro.Status != "Disponivel")
                {
                    ViewBag.Erro = "Veículo indisponível para venda!";
                    PreencheDadosParaView("I", venda);
                    return View("Form", venda);
                }

                if (venda.Desconto < 0 || venda.Desconto > venda.ValorVenda)
                {
                    ViewBag.Erro = "Desconto inválido!";
                    PreencheDadosParaView("I", venda);
                    return View("Form", venda);
                }

                using (var transacao = new TransactionScope())
                {
                    VendaDAO vendaDao = new VendaDAO();
                    venda.DataVenda = DateTime.Now;
                    venda.Status = "Concluida";
                    venda.FuncionarioId = 1; // ajuste conforme funcionário autenticado
                    int vendaId = vendaDao.Insert(venda);

                    if (venda.QtdParcelas > 1)
                    {
                        ParcelaDAO parcelaDao = new ParcelaDAO();
                        decimal saldo = venda.ValorVenda - venda.Desconto - venda.ValorEntrada;
                        decimal valorParcela = Math.Round(saldo / venda.QtdParcelas, 2);

                        for (int i = 1; i <= venda.QtdParcelas; i++)
                        {
                            parcelaDao.Insert(new ParcelaViewModel
                            {
                                VendaId = vendaId,
                                NumeroParcela = i,
                                Valor = valorParcela > 0 ? valorParcela : 0.01m,
                                DataVencimento = DateTime.Today.AddMonths(i),
                                Status = "Pendente"
                            });
                        }
                    }

                    vendaDao.AtualizaStatusCarro(venda.CarroId, "Vendido");
                    transacao.Complete();
                }

                return RedirectToAction("Index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
    }
}
