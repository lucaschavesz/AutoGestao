﻿using AutoGestao.DAO;
using AutoGestao.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;

namespace AutoGestao.Controllers
{
    public class LoginController : Controller
    {
        private void PreparaComboFuncionarios()
        {
            UsuarioDAO usuarioDao = new UsuarioDAO();
            var funcionarios = usuarioDao.ListarFuncionariosSemUsuario();
            List<SelectListItem> itens = new List<SelectListItem>();
            itens.Add(new SelectListItem("Selecione um funcionário...", "0"));

            foreach (var f in funcionarios)
            {
                itens.Add(new SelectListItem($"{f.Nome} ({f.Cargo})", f.Id.ToString()));
            }

            ViewBag.Funcionarios = itens;
        }

        public IActionResult Index()
        {
            ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
            ViewBag.Perfil = HttpContext.Session.GetString("UsuarioPerfil");
            PreparaComboFuncionarios();
            return View(new UsuarioViewModel { Ativo = true, Perfil = "Funcionario" });
        }

        public IActionResult FazLogin(string usuario, string senha)
        {
            try
            {
                UsuarioDAO dao = new UsuarioDAO();
                var user = dao.Autenticar(usuario, senha);

                if (user != null)
                {
                    HttpContext.Session.SetString("Logado", "true");
                    HttpContext.Session.SetString("UsuarioNome", user.Login);
                    HttpContext.Session.SetString("UsuarioPerfil", user.Perfil);
                    HttpContext.Session.SetString("FuncionarioId", user.FuncionarioId.ToString());
                    HttpContext.Session.SetString("ClienteId", user.ClienteId.HasValue ? user.ClienteId.Value.ToString() : "");
                    return RedirectToAction("Index", "Home");
                }

                ViewBag.Erro = "Usuário ou senha inválidos!";
                PreparaComboFuncionarios();
                return View("Index", new UsuarioViewModel { Ativo = true, Perfil = "Funcionario" });
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }

        [HttpPost]
        public IActionResult CadastrarUsuario(UsuarioViewModel novoUsuario)
        {
            try
            {
                ModelState.Clear();
                UsuarioDAO dao = new UsuarioDAO();

                if (novoUsuario.FuncionarioId <= 0)
                    ModelState.AddModelError("FuncionarioId", "Selecione um funcionário.");
                if (string.IsNullOrWhiteSpace(novoUsuario.Login))
                    ModelState.AddModelError("Login", "Informe o login.");
                else if (dao.ExisteLogin(novoUsuario.Login.Trim()))
                    ModelState.AddModelError("Login", "Este login já está em uso.");
                if (string.IsNullOrWhiteSpace(novoUsuario.SenhaHash))
                    ModelState.AddModelError("SenhaHash", "Informe a senha.");
                if (novoUsuario.Perfil != "Administrador" && novoUsuario.Perfil != "Funcionario")
                    novoUsuario.Perfil = "Funcionario";

                if (!ModelState.IsValid)
                {
                    ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
                    PreparaComboFuncionarios();
                    return View("Index", novoUsuario);
                }

                novoUsuario.Login = novoUsuario.Login.Trim();
                novoUsuario.Ativo = true;
                dao.Insert(novoUsuario);

                ViewBag.MensagemCadastro = "Usuário cadastrado com sucesso! Já é possível fazer login.";
                ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
                PreparaComboFuncionarios();
                return View("Index", new UsuarioViewModel { Ativo = true, Perfil = "Funcionario" });
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }

        [HttpGet]
        public IActionResult CadastroCliente()
        {
            ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
            return View(new ClienteViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CadastrarCliente(ClienteViewModel cliente, string senha, string confirmarSenha)
        {
            try
            {
                ModelState.Clear();
                UsuarioDAO usuarioDao = new UsuarioDAO();
                string cpf = System.Text.RegularExpressions.Regex.Replace(cliente.Cpf ?? "", @"\D", "");
                string email = (cliente.Email ?? "").Trim().ToLowerInvariant();

                if (string.IsNullOrWhiteSpace(cliente.Nome)) ModelState.AddModelError("Nome", "Informe seu nome.");
                if (cpf.Length != 11) ModelState.AddModelError("Cpf", "Informe um CPF com 11 números.");
                if (string.IsNullOrWhiteSpace(email) || !email.Contains("@")) ModelState.AddModelError("Email", "Informe um e-mail válido.");
                if (cliente.DataNascimento == DateTime.MinValue) ModelState.AddModelError("DataNascimento", "Informe sua data de nascimento.");
                if (string.IsNullOrWhiteSpace(senha) || senha.Length < 6) ModelState.AddModelError("Senha", "A senha deve ter pelo menos 6 caracteres.");
                if (senha != confirmarSenha) ModelState.AddModelError("ConfirmarSenha", "As senhas não coincidem.");

                cliente.Cpf = cpf;
                cliente.Email = email;
                if (!ModelState.IsValid)
                {
                    ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
                    return View("CadastroCliente", cliente);
                }

                if (usuarioDao.CpfPertenceAOutraPessoa(cpf))
                {
                    ModelState.AddModelError("Cpf", "Este CPF já está vinculado a um cadastro que não é de cliente. Entre em contato com a revenda.");
                    ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
                    return View("CadastroCliente", cliente);
                }

                if (usuarioDao.ExisteLogin(email))
                {
                    ModelState.AddModelError("Email", "Este e-mail já está sendo utilizado como login.");
                    ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
                    return View("CadastroCliente", cliente);
                }

                int clienteId = usuarioDao.BuscarClientePorCpf(cpf);
                if (clienteId == 0)
                {
                    cliente.TipoPessoa = "Cliente";
                    cliente.DataCadastro = DateTime.Now;
                    new ClienteDAO().Insert(cliente);
                    // O DAO de clientes utiliza uma stored procedure sem retorno de identidade.
                    clienteId = usuarioDao.BuscarClientePorCpf(cpf);
                    if (clienteId == 0)
                        throw new Exception("Não foi possível localizar o cliente após o cadastro.");
                }
                if (usuarioDao.ClienteJaPossuiUsuario(clienteId))
                {
                    ModelState.AddModelError("Cpf", "Já existe uma conta vinculada a este CPF. Faça login.");
                    ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
                    return View("CadastroCliente", cliente);
                }

                usuarioDao.CadastrarAcessoCliente(clienteId, email, senha);
                TempData["MensagemLogin"] = "Cadastro realizado! Entre com seu e-mail ou CPF e sua senha.";
                return RedirectToAction("AcessoCliente");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }

        [HttpGet]
        public IActionResult AcessoCliente()
        {
            ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
            ViewBag.Mensagem = TempData["MensagemLogin"];
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult LoginCliente(string identificador, string senha)
        {
            try
            {
                string loginInformado = (identificador ?? "").Trim();
                if (!loginInformado.Contains("@"))
                    loginInformado = System.Text.RegularExpressions.Regex.Replace(loginInformado, @"\D", "");
                UsuarioViewModel user = new UsuarioDAO().AutenticarCliente(loginInformado, senha);
                if (user == null)
                {
                    ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
                    ViewBag.Erro = "E-mail/CPF ou senha inválidos.";
                    return View("AcessoCliente");
                }
                HttpContext.Session.Clear();
                HttpContext.Session.SetString("Logado", "true");
                HttpContext.Session.SetString("UsuarioPerfil", "Cliente");
                HttpContext.Session.SetString("UsuarioNome", user.Login);
                HttpContext.Session.SetString("ClienteId", user.ClienteId.Value.ToString());
                return RedirectToAction("Index", "Home");
            }
            catch (Exception erro) { return View("Error", new ErrorViewModel(erro.ToString())); }
        }

        public IActionResult LogOff()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
    }
}
