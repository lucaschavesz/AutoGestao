﻿using AutoGestao.DAO;
using AutoGestao.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;

namespace AutoGestao.Controllers
{
    public class CarroController : PadraoController<CarroViewModel>
    {
        private readonly IWebHostEnvironment _environment;

        public CarroController(IWebHostEnvironment environment)
        {
            _environment = environment;
            DAO = new CarroDAO();
            GeraProximoId = true;
        }

        [HttpPost]
        public IActionResult SalvarCarro(CarroViewModel model, string Operacao, List<IFormFile> fotos)
        {
            try
            {
                var ptBr = new CultureInfo("pt-BR");

                if (!string.IsNullOrWhiteSpace(Request.Form["ValorFipe"]))
                {
                    string textoFipe = Request.Form["ValorFipe"].ToString().Replace("R$", "").Trim();
                    if (textoFipe.Contains(".") && !textoFipe.Contains(","))
                        textoFipe = textoFipe.Replace(".", ",");
                    else if (textoFipe.Contains(".") && textoFipe.Contains(","))
                        textoFipe = textoFipe.Replace(".", "");

                    if (decimal.TryParse(textoFipe, NumberStyles.Number, ptBr, out decimal vf))
                        model.ValorFipe = vf;
                }

                if (!string.IsNullOrWhiteSpace(Request.Form["ValorVenda"]))
                {
                    string textoVenda = Request.Form["ValorVenda"].ToString().Replace("R$", "").Trim();
                    if (textoVenda.Contains(".") && !textoVenda.Contains(","))
                        textoVenda = textoVenda.Replace(".", ",");
                    else if (textoVenda.Contains(".") && textoVenda.Contains(","))
                        textoVenda = textoVenda.Replace(".", "");

                    if (decimal.TryParse(textoVenda, NumberStyles.Number, ptBr, out decimal vv))
                        model.ValorVenda = vv;
                }

                // ValidaDados limpa o ModelState e faz as validações no controller (padrão da apostila)
                ValidaDados(model, Operacao);
                if (!ModelState.IsValid)
                {
                    ViewBag.Operacao = Operacao;
                    return View(NomeViewForm, model);
                }

                int carroId = model.Id;
                if (Operacao == "I")
                {
                    DAO.Insert(model);
                    carroId = model.Id > 0 ? model.Id : DAO.ProximoId() - 1;
                }
                else
                {
                    DAO.Update(model);
                }

                if (fotos != null && fotos.Count > 0)
                {
                    string pastaDestino = Path.Combine(_environment.WebRootPath, "imagens", "carros");
                    if (!Directory.Exists(pastaDestino))
                        Directory.CreateDirectory(pastaDestino);

                    CarroFotoDAO fotoDao = new CarroFotoDAO();
                    for (int i = 0; i < fotos.Count; i++)
                    {
                        var arquivo = fotos[i];
                        if (arquivo != null && arquivo.Length > 0)
                        {
                            string nomeArquivo = $"{Guid.NewGuid()}_{Path.GetFileName(arquivo.FileName)}";
                            string caminhoFisico = Path.Combine(pastaDestino, nomeArquivo);
                            using (var stream = new FileStream(caminhoFisico, FileMode.Create))
                            {
                                arquivo.CopyTo(stream);
                            }

                            fotoDao.Insert(new CarroFotoViewModel
                            {
                                CarroId = carroId,
                                CaminhoImagem = "/imagens/carros/" + nomeArquivo,
                                FotoPrincipal = (i == 0)
                            });
                        }
                    }
                }

                return RedirectToAction(NomeViewIndex);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }

        protected override void ValidaDados(CarroViewModel model, string operacao)
        {
            base.ValidaDados(model, operacao);
            if (string.IsNullOrEmpty(model.Marca))
                ModelState.AddModelError("Marca", "Informe a marca.");
            if (string.IsNullOrEmpty(model.Modelo))
                ModelState.AddModelError("Modelo", "Informe o modelo.");
            if (model.Ano < 1900 || model.Ano > 2100)
                ModelState.AddModelError("Ano", "Ano inválido.");
            if (model.Quilometragem < 0)
                ModelState.AddModelError("Quilometragem", "Quilometragem inválida.");
            if (model.ValorVenda < 0)
                ModelState.AddModelError("ValorVenda", "Valor de venda inválido.");
        }

        // Consumo de API externa (FIPE) via HttpClient no Controller (conforme seção 37 da apostila)
        public IActionResult ConsultarFipeEndpoint(string rota)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    string url = "https://fipe.parallelum.com.br/api/v2/" + rota;
                    using (var response = httpClient.GetAsync(url).Result)
                    {
                        if (response.StatusCode == System.Net.HttpStatusCode.OK)
                        {
                            string resposta = response.Content.ReadAsStringAsync().Result;
                            return Content(resposta, "application/json");
                        }
                        throw new Exception("Erro FIPE. Status: " + response.StatusCode);
                    }
                }
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }

        // Consulta avançada com AJAX + PartialView (conforme seção 36 da apostila)
        public IActionResult ExibeConsultaAvancada()
        {
            CarroDAO dao = new CarroDAO();
            var carros = dao.Listagem();
            var marcas = carros.Select(c => c.Marca).Distinct().OrderBy(m => m)
                .Select(m => new SelectListItem(m, m)).ToList();
            marcas.Insert(0, new SelectListItem("TODAS", ""));
            ViewBag.Marcas = marcas;
            return View("ConsultaAvancada");
        }

        public IActionResult ObtemDadosConsultaAvancada(string modelo, string marca, string status, DateTime dataInicial, DateTime dataFinal)
        {
            try
            {
                CarroDAO dao = new CarroDAO();
                if (string.IsNullOrEmpty(modelo)) modelo = "";
                if (dataInicial.Date == DateTime.MinValue.Date) dataInicial = SqlDateTime.MinValue.Value;
                if (dataFinal.Date == DateTime.MinValue.Date) dataFinal = SqlDateTime.MaxValue.Value;

                var lista = dao.ConsultaAvancada(modelo, marca, status, dataInicial, dataFinal);
                return PartialView("pvGridCarros", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }
    }
}
