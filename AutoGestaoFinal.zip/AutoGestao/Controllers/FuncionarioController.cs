﻿using AutoGestao.DAO;
using AutoGestao.Models;
using System;

namespace AutoGestao.Controllers
{
    public class FuncionarioController : PadraoController<FuncionarioViewModel>
    {
        public FuncionarioController()
        {
            DAO = new FuncionarioDAO();
            GeraProximoId = true;
        }

        protected override void PreencheDadosParaView(string Operacao, FuncionarioViewModel model)
        {
            base.PreencheDadosParaView(Operacao, model);
            if (Operacao == "I")
            {
                if (model.DataNascimento == DateTime.MinValue)
                    model.DataNascimento = DateTime.Today.AddYears(-18);
                if (model.DataContratacao == DateTime.MinValue)
                    model.DataContratacao = DateTime.Today;
                model.StatusFuncionario = true;
            }
        }

        protected override void ValidaDados(FuncionarioViewModel model, string operacao)
        {
            base.ValidaDados(model, operacao);

            if (string.IsNullOrEmpty(model.Nome))
                ModelState.AddModelError("Nome", "Preencha o nome.");

            if (string.IsNullOrEmpty(model.Cpf))
                ModelState.AddModelError("Cpf", "Preencha o CPF.");

            if (string.IsNullOrEmpty(model.Cargo))
                ModelState.AddModelError("Cargo", "Preencha o cargo.");

            if (model.Salario.HasValue && model.Salario.Value < 0)
                ModelState.AddModelError("Salario", "Salário não pode ser negativo.");

            if (model.DataContratacao == DateTime.MinValue)
                ModelState.AddModelError("DataContratacao", "Informe a data de contratação.");
        }
    }
}
