﻿using AutoGestao.DAO;
using AutoGestao.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace AutoGestao.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
            CarroDAO carroDao = new CarroDAO();
            CarroFotoDAO fotoDao = new CarroFotoDAO();
            var disponiveis = carroDao.Listagem().Where(c => c.Status == "Disponivel").ToList();

            foreach (var carro in disponiveis)
            {
                carro.Fotos = fotoDao.ListarCaminhosPorCarro(carro.Id);
                if (carro.Fotos.Count == 0 && !string.IsNullOrEmpty(carro.FotoPrincipalCaminho))
                {
                    carro.Fotos.Add(carro.FotoPrincipalCaminho);
                }
            }

            return View(disponiveis);
        }
    }
}
