﻿using AutoGestao.DAO;
using AutoGestao.Models;
using System;
using Microsoft.AspNetCore.Mvc;

namespace AutoGestao.Controllers
{
    public class ClienteController : PadraoController<ClienteViewModel>
    {
        public ClienteController()
        {
            DAO = new ClienteDAO();
            GeraProximoId = true;
        }

        protected override void PreencheDadosParaView(string Operacao, ClienteViewModel model)
        {
            base.PreencheDadosParaView(Operacao, model);
            if (Operacao == "I")
            {
                model.DataNascimento = DateTime.Today.AddYears(-18);
                model.DataCadastro = DateTime.Now;
            }
        }

        protected override void ValidaDados(ClienteViewModel model, string operacao)
        {
            base.ValidaDados(model, operacao);
            if (string.IsNullOrEmpty(model.Nome))
                ModelState.AddModelError("Nome", "Preencha o nome.");
            if (string.IsNullOrEmpty(model.Cpf))
                ModelState.AddModelError("Cpf", "Preencha o CPF.");
        }

        public IActionResult ExibeConsultaAvancada()
        {
            return View("ConsultaAvancada");
        }

        public IActionResult ObtemDadosConsultaAvancada(
            string nome, string cpf, string cidade, string telefone,
            DateTime? dataInicial, DateTime? dataFinal)
        {
            try
            {
                ClienteDAO dao = new ClienteDAO();
                var lista = dao.ConsultaAvancada(
                    nome, cpf, cidade, telefone, dataInicial, dataFinal);
                return PartialView("pvGridClientes", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }

    }
}
