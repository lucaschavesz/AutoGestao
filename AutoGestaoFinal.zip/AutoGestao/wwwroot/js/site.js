﻿function aplicaFiltroCarros() {
    var vModelo = document.getElementById('modelo').value;
    var vMarca = document.getElementById('marca').value;
    var vStatus = document.getElementById('status').value;
    var vDataInicial = document.getElementById('dataInicial').value;
    var vDataFinal = document.getElementById('dataFinal').value;

    $.ajax({
        url: "/Carro/ObtemDadosConsultaAvancada",
        data: {
            modelo: vModelo,
            marca: vMarca,
            status: vStatus,
            dataInicial: vDataInicial,
            dataFinal: vDataFinal
        },
        success: function (dados) {
            if (dados.erro != undefined) {
                alert(dados.msg);
            } else {
                document.getElementById('resultadoConsulta').innerHTML = dados;
            }
        }
    });
}

function buscaCepCliente() {
    var cep = document.getElementById("Cep").value.replace("-", "").trim();
    if (cep.length > 0) {
        $.ajax({
            url: "https://viacep.com.br/ws/" + cep + "/json/",
            success: function (dados) {
                if (dados.erro != undefined) {
                    alert("CEP não localizado...");
                } else {
                    document.getElementById("Rua").value = dados.logradouro;
                    document.getElementById("Bairro").value = dados.bairro;
                    document.getElementById("Cidade").value = dados.localidade;
                }
            }
        });
    }
}

function carregarMarcasFipe() {
    $.ajax({
        url: "/Carro/ConsultarFipeEndpoint",
        data: { rota: "cars/brands" },
        success: function (dados) {
            var ddl = $("#ddlMarcaFipe");
            ddl.empty();
            ddl.append('<option value="">Selecione a marca...</option>');
            $.each(dados, function (i, item) {
                ddl.append('<option value="' + item.code + '">' + item.name + '</option>');
            });
        }
    });
}

function carregarModelosFipe() {
    var marcaId = $("#ddlMarcaFipe").val();
    $("#CodigoMarcaFipe").val(marcaId);
    $("#Marca").val($("#ddlMarcaFipe option:selected").text());

    var ddlModelo = $("#ddlModeloFipe");
    ddlModelo.empty();
    ddlModelo.append('<option value="">Carregando...</option>');

    if (!marcaId) return;

    $.ajax({
        url: "/Carro/ConsultarFipeEndpoint",
        data: { rota: "cars/brands/" + marcaId + "/models" },
        success: function (dados) {
            ddlModelo.empty();
            ddlModelo.append('<option value="">Selecione o modelo...</option>');
            $.each(dados, function (i, item) {
                ddlModelo.append('<option value="' + item.code + '">' + item.name + '</option>');
            });
        }
    });
}

function carregarAnosFipe() {
    var marcaId = $("#ddlMarcaFipe").val();
    var modeloId = $("#ddlModeloFipe").val();
    $("#CodigoModeloFipe").val(modeloId);
    $("#Modelo").val($("#ddlModeloFipe option:selected").text());

    var ddlAno = $("#ddlAnoFipe");
    ddlAno.empty();
    ddlAno.append('<option value="">Carregando...</option>');

    if (!marcaId || !modeloId) return;

    $.ajax({
        url: "/Carro/ConsultarFipeEndpoint",
        data: { rota: "cars/brands/" + marcaId + "/models/" + modeloId + "/years" },
        success: function (dados) {
            ddlAno.empty();
            ddlAno.append('<option value="">Selecione o ano...</option>');
            $.each(dados, function (i, item) {
                ddlAno.append('<option value="' + item.code + '">' + item.name + '</option>');
            });
        }
    });
}

function consultarDetalhesFipe() {
    var marcaId = $("#ddlMarcaFipe").val();
    var modeloId = $("#ddlModeloFipe").val();
    var anoId = $("#ddlAnoFipe").val();
    $("#CodigoAnoFipe").val(anoId);

    if (!marcaId || !modeloId || !anoId) return;

    $.ajax({
        url: "/Carro/ConsultarFipeEndpoint",
        data: { rota: "cars/brands/" + marcaId + "/models/" + modeloId + "/years/" + anoId },
        success: function (dados) {
            $("#CodigoFipe").val(dados.codeFipe);
            $("#Combustivel").val(dados.fuel);
            $("#MesReferenciaFipe").val(dados.referenceMonth);

            if (dados.modelYear) {
                $("#Ano").val(dados.modelYear);
            }
            if (dados.price) {
                // Exemplo da API: "R$ 45.193,00" -> remove "R$" e pontos de milhar -> "45193,00"
                var valorLimpo = dados.price.replace("R$", "").replace(/\./g, "").trim();
                $("#ValorFipe").val(valorLimpo);
            }
        }
    });
}

/* =====================================================================
   Utilidades de interface (visual novo)
   ===================================================================== */

// Exclusão com confirmação: apagarRegistro('/Carro/Delete', 5)
function apagarRegistro(url, id) {
    if (confirm('Confirma a exclusão do registro?')) {
        location.href = url + '?id=' + id;
    }
}

// Converte "1.234,56" ou "1234.56" para número (mesma regra usada no CarroController)
function parseValorBR(texto) {
    if (texto === undefined || texto === null) return 0;
    var t = String(texto).replace('R$', '').trim();
    if (t === '') return 0;
    if (t.indexOf(',') >= 0) t = t.replace(/\./g, '').replace(',', '.');
    var n = parseFloat(t);
    return isNaN(n) ? 0 : n;
}

function formataMoeda(valor) {
    return Number(valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function formataDataISO(iso) {
    if (!iso) return '-';
    var p = String(iso).substring(0, 10).split('-');
    return p[2] + '/' + p[1] + '/' + p[0];
}


// Painel da Home alimentado pelas APIs de relatório
function carregarPainelHome() {
    // Painel alimentado pelas APIs de relatório (/api/relatorios/...)
    function setKpi(id, texto) {
        var el = document.getElementById(id);
        if (!el) return;
        el.classList.remove('skeleton');
        el.textContent = texto;
    }

    function falhaPainel() {
        document.getElementById('painelPeriodo').textContent = 'Não foi possível carregar os indicadores.';
        ['kpiFaturamento', 'kpiVendas', 'kpiPendente', 'kpiEstoque'].forEach(function (id) { setKpi(id, '—'); });
    }

    $.getJSON('/api/relatorios/resumo-vendas').done(function (d) {
        document.getElementById('painelPeriodo').textContent = 'Todo o histórico';
        setKpi('kpiFaturamento', formataMoeda(d.vendas.faturamentoLiquido));
        document.getElementById('kpiFaturamentoNota').textContent = 'Bruto ' + formataMoeda(d.vendas.faturamentoBruto);
        setKpi('kpiVendas', d.vendas.quantidade);
        document.getElementById('kpiTicket').textContent = 'Ticket médio ' + formataMoeda(d.vendas.ticketMedio);
        setKpi('kpiPendente', formataMoeda(d.parcelas.valorPendente + d.parcelas.valorAtrasado));
        document.getElementById('kpiAtrasado').textContent = d.parcelas.quantidadeAtrasadas + ' em atraso (' + formataMoeda(d.parcelas.valorAtrasado) + ')';
        setKpi('kpiEstoque', d.estoque.disponivel);
        document.getElementById('kpiEstoqueNota').textContent = formataMoeda(d.estoque.valorEmEstoque) + ' em veículos';
    }).fail(falhaPainel);

    $.getJSON('/api/relatorios/desempenho').done(function (d) {
        document.getElementById('graficoAno').textContent = d.ano;
        var max = Math.max.apply(null, d.porMes.map(function (m) { return m.faturamentoLiquido; }));
        var html = '';
        d.porMes.forEach(function (m) {
            var pct = max > 0 ? Math.max(2, Math.round(m.faturamentoLiquido / max * 100)) : 2;
            var dica = m.nomeMes + ': ' + formataMoeda(m.faturamentoLiquido) + ' (' + m.quantidade + ' venda(s))';
            html += '<div class="bar-col" title="' + dica + '">' +
                    '<div class="bar' + (m.faturamentoLiquido > 0 ? '' : ' zero') + '" style="height:' + pct + '%"></div>' +
                    '<div class="bar-label">' + m.nomeMes.substring(0, 3) + '</div></div>';
        });
        document.getElementById('graficoMensal').innerHTML = html;
    });
}


// Formulário de venda: preenche o valor ao escolher o veículo e atualiza o resumo lateral
function iniciaFormVenda(precos) {
    var $carro = $('#CarroId'), $valor = $('#ValorVenda'), $desc = $('#Desconto'),
        $entrada = $('#ValorEntrada'), $parc = $('#QtdParcelas');

    function atualizaResumo() {
        var bruto = parseValorBR($valor.val());
        var desconto = parseValorBR($desc.val());
        var entrada = parseValorBR($entrada.val());
        var parcelas = parseInt($parc.val()) || 1;
        var saldo = Math.max(0, bruto - desconto - entrada);

        $('#resBruto').text(formataMoeda(bruto));
        $('#resDesconto').text(formataMoeda(desconto));
        $('#resEntrada').text(formataMoeda(entrada));
        $('#resSaldo').text(formataMoeda(saldo));
        $('#resParcelas').text(parcelas > 1
            ? parcelas + ' parcelas de ' + formataMoeda(saldo / parcelas)
            : 'Pagamento à vista do saldo (sem parcelas geradas).');
    }

    function preencheValorDoCarro() {
        var item = precos[$carro.val()];
        if (item) { $valor.val(item.texto); }
        atualizaResumo();
    }

    $carro.on('change', preencheValorDoCarro);
    $('#ValorVenda, #Desconto, #ValorEntrada, #QtdParcelas').on('input change', atualizaResumo);

    // Ao abrir a tela, se o valor ainda está zerado, usa o preço do veículo selecionado
    if (parseValorBR($valor.val()) === 0) { preencheValorDoCarro(); } else { atualizaResumo(); }
}


// Consulta avançada de clientes: filtros enviados por AJAX.
function aplicaFiltroClientes() {
    var parametros = {
        nome: document.getElementById('clienteNome').value,
        cpf: document.getElementById('clienteCpf').value,
        cidade: document.getElementById('clienteCidade').value,
        telefone: document.getElementById('clienteTelefone').value,
        dataInicial: document.getElementById('clienteDataInicial').value,
        dataFinal: document.getElementById('clienteDataFinal').value
    };

    $.ajax({
        url: '/Cliente/ObtemDadosConsultaAvancada',
        data: parametros,
        success: function (dados) {
            if (dados && dados.erro !== undefined) {
                alert(dados.msg);
            } else {
                document.getElementById('resultadoConsultaClientes').innerHTML = dados;
            }
        },
        error: function () {
            alert('Não foi possível realizar a consulta de clientes.');
        }
    });
}

function limparFiltroClientes() {
    document.getElementById('clienteNome').value = '';
    document.getElementById('clienteCpf').value = '';
    document.getElementById('clienteCidade').value = '';
    document.getElementById('clienteTelefone').value = '';
    document.getElementById('clienteDataInicial').value = '';
    document.getElementById('clienteDataFinal').value = '';
    document.getElementById('resultadoConsultaClientes').innerHTML =
        '<div class="empty-state"><div>Defina os filtros e clique em “Aplicar filtros”.</div></div>';
}
