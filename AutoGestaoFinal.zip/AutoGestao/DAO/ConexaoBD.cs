﻿using System.Data.SqlClient;

namespace AutoGestao.DAO
{
    public static class ConexaoBD
    {
        public static SqlConnection GetConexao()
        {
            string strCon = "Data Source=DESKTOP-6IJNLKD; Initial Catalog=AutoGestao; integrated security=true";
            SqlConnection conexao = new SqlConnection(strCon);
            conexao.Open();
            return conexao;
        }
    }
}
