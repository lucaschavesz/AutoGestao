﻿using AutoGestao.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace AutoGestao.DAO
{
    public class CarroFotoDAO : PadraoDAO<CarroFotoViewModel>
    {
        protected override void SetTabela()
        {
            Tabela = "CarroFoto";
            ChaveIdentity = true;
        }

        protected override SqlParameter[] CriaParametros(CarroFotoViewModel model)
        {
            return new SqlParameter[]
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("carro_id", model.CarroId),
                new SqlParameter("caminho_imagem", model.CaminhoImagem),
                new SqlParameter("foto_principal", model.FotoPrincipal)
            };
        }

        protected override CarroFotoViewModel MontaModel(DataRow r)
        {
            return new CarroFotoViewModel
            {
                Id = Convert.ToInt32(r["id"]),
                CarroId = Convert.ToInt32(r["carro_id"]),
                CaminhoImagem = r["caminho_imagem"].ToString(),
                FotoPrincipal = Convert.ToBoolean(r["foto_principal"])
            };
        }
        public List<string> ListarCaminhosPorCarro(int carroId)
        {
            var p = new SqlParameter[]
            {
        new SqlParameter("carro_id", carroId)
            };
            string sql = "SELECT caminho_imagem FROM CarroFoto WHERE carro_id = @carro_id ORDER BY foto_principal DESC, id ASC";
            List<string> caminhos = new List<string>();

            using (SqlConnection conexao = ConexaoBD.GetConexao())
            {
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddRange(p);
                    using (SqlDataReader reader = comando.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            caminhos.Add(reader["caminho_imagem"].ToString());
                        }
                    }
                }
            }
            return caminhos;
        }
    }
}
