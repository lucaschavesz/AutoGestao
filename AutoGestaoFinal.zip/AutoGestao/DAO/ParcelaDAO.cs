﻿using AutoGestao.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace AutoGestao.DAO
{
    public class ParcelaDAO : PadraoDAO<ParcelaViewModel>
    {
        protected override void SetTabela()
        {
            Tabela = "Parcela";
            NomeSpListagem = "spListagemParcelas";
            ChaveIdentity = true;
        }

        public override List<ParcelaViewModel> Listagem()
        {
            return ListagemPorVenda(0);
        }

        public List<ParcelaViewModel> ListagemPorVenda(int vendaId)
        {
            var p = new SqlParameter[]
            {
            new SqlParameter("vendaId", vendaId)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemParcelas", p);
            List<ParcelaViewModel> lista = new List<ParcelaViewModel>();
            foreach (DataRow r in tabela.Rows)
                lista.Add(MontaModel(r));
            return lista;
        }

        protected override SqlParameter[] CriaParametros(ParcelaViewModel model)
        {
            return new SqlParameter[]
            {
            new SqlParameter("id", model.Id),
            new SqlParameter("venda_id", model.VendaId),
            new SqlParameter("numero_parcela", model.NumeroParcela),
            new SqlParameter("valor", model.Valor),
            new SqlParameter("data_vencimento", model.DataVencimento),
            new SqlParameter("data_pagamento", model.DataPagamento.HasValue ? (object)model.DataPagamento.Value : DBNull.Value),
            new SqlParameter("status", model.Status)
            };
        }

        protected override ParcelaViewModel MontaModel(DataRow r)
        {
            var p = new ParcelaViewModel
            {
                Id = Convert.ToInt32(r["id"]),
                VendaId = Convert.ToInt32(r["venda_id"]),
                NumeroParcela = Convert.ToInt32(r["numero_parcela"]),
                Valor = Convert.ToDecimal(r["valor"]),
                DataVencimento = Convert.ToDateTime(r["data_vencimento"]),
                DataPagamento = r["data_pagamento"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(r["data_pagamento"]),
                Status = r["status"].ToString()
            };

            if (r.Table.Columns.Contains("cliente_nome") && r["cliente_nome"] != DBNull.Value)
                p.ClienteNome = r["cliente_nome"].ToString();

            return p;
        }
    }
}
