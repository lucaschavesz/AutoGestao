using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using AutoGestao.Models.Api;

namespace AutoGestao.DAO
{
    /// <summary>
    /// Consultas consolidadas (somente leitura) sobre as vendas geradas pelo sistema.
    /// Regra comum: só entram vendas cujo status é diferente de 'Cancelada'.
    /// Valor líquido = valor_venda - desconto.
    /// </summary>
    public class RelatorioDAO
    {
        private static SqlParameter ParamData(string nome, DateTime? valor)
        {
            var p = new SqlParameter(nome, SqlDbType.DateTime);
            p.Value = valor.HasValue ? (object)valor.Value : DBNull.Value;
            return p;
        }

        private static decimal Dec(object o) { return o == DBNull.Value ? 0m : Convert.ToDecimal(o); }
        private static int Int(object o) { return o == DBNull.Value ? 0 : Convert.ToInt32(o); }

        // dataFinalExclusiva = dia seguinte à data final informada (pega o dia inteiro)
        private const string FiltroPeriodo =
            " v.status <> 'Cancelada' AND (@ini IS NULL OR v.data_venda >= @ini) AND (@fim IS NULL OR v.data_venda < @fim) ";

        private static SqlParameter[] ParamsPeriodo(DateTime? ini, DateTime? fimInclusivo)
        {
            return new SqlParameter[]
            {
                ParamData("ini", ini.HasValue ? (DateTime?)ini.Value.Date : null),
                ParamData("fim", fimInclusivo.HasValue ? (DateTime?)fimInclusivo.Value.Date.AddDays(1) : null)
            };
        }

        // ======================= API 1 =======================
        public TotaisVendasDto TotaisVendas(DateTime? ini, DateTime? fim)
        {
            string sql = @"SELECT COUNT(*) AS qtd,
                                  ISNULL(SUM(v.valor_venda), 0) AS bruto,
                                  ISNULL(SUM(v.desconto), 0) AS descontos,
                                  ISNULL(SUM(v.valor_entrada), 0) AS entradas
                           FROM Venda v WHERE" + FiltroPeriodo;
            var r = HelperDAO.ExecutaSelect(sql, ParamsPeriodo(ini, fim)).Rows[0];

            var t = new TotaisVendasDto
            {
                Quantidade = Int(r["qtd"]),
                FaturamentoBruto = Dec(r["bruto"]),
                TotalDescontos = Dec(r["descontos"]),
                TotalEntradas = Dec(r["entradas"])
            };
            t.FaturamentoLiquido = t.FaturamentoBruto - t.TotalDescontos;
            t.TicketMedio = t.Quantidade > 0 ? Math.Round(t.FaturamentoLiquido / t.Quantidade, 2) : 0m;
            t.DescontoMedioPercentual = t.FaturamentoBruto > 0 ? Math.Round(t.TotalDescontos / t.FaturamentoBruto * 100m, 2) : 0m;
            return t;
        }

        public List<FormaPagamentoDto> PorFormaPagamento(DateTime? ini, DateTime? fim)
        {
            string sql = @"SELECT v.forma_pagamento, COUNT(*) AS qtd, ISNULL(SUM(v.valor_venda - v.desconto), 0) AS liquido
                           FROM Venda v WHERE" + FiltroPeriodo + @"
                           GROUP BY v.forma_pagamento ORDER BY liquido DESC";
            var tabela = HelperDAO.ExecutaSelect(sql, ParamsPeriodo(ini, fim));

            decimal total = 0m;
            foreach (DataRow r in tabela.Rows) total += Dec(r["liquido"]);

            var lista = new List<FormaPagamentoDto>();
            foreach (DataRow r in tabela.Rows)
            {
                decimal valor = Dec(r["liquido"]);
                lista.Add(new FormaPagamentoDto
                {
                    FormaPagamento = r["forma_pagamento"] == DBNull.Value ? "Não informado" : r["forma_pagamento"].ToString(),
                    Quantidade = Int(r["qtd"]),
                    ValorLiquido = valor,
                    Percentual = total > 0 ? Math.Round(valor / total * 100m, 2) : 0m
                });
            }
            return lista;
        }

        public EstoqueDto Estoque()
        {
            string sql = @"SELECT status, COUNT(*) AS qtd, ISNULL(SUM(valor_venda), 0) AS valor FROM Carro GROUP BY status";
            var e = new EstoqueDto();
            foreach (DataRow r in HelperDAO.ExecutaSelect(sql, null).Rows)
            {
                int qtd = Int(r["qtd"]);
                string status = r["status"].ToString();
                e.Total += qtd;
                if (status == "Disponivel") { e.Disponivel = qtd; e.ValorEmEstoque = Dec(r["valor"]); }
                else if (status == "Reservado") e.Reservado = qtd;
                else if (status == "Vendido") e.Vendido = qtd;
            }
            return e;
        }

        // Pago = tem data de pagamento; Atrasada = não paga e vencida; Pendente = não paga e a vencer.
        public CarteiraParcelasDto CarteiraParcelas()
        {
            string sql = @"SELECT situacao, COUNT(*) AS qtd, ISNULL(SUM(valor), 0) AS total
                           FROM (SELECT valor,
                                        CASE WHEN data_pagamento IS NOT NULL THEN 'Paga'
                                             WHEN data_vencimento < CAST(GETDATE() AS date) THEN 'Atrasada'
                                             ELSE 'Pendente' END AS situacao
                                 FROM Parcela) x
                           GROUP BY situacao";
            var c = new CarteiraParcelasDto();
            foreach (DataRow r in HelperDAO.ExecutaSelect(sql, null).Rows)
            {
                string s = r["situacao"].ToString();
                if (s == "Paga") { c.QuantidadePagas = Int(r["qtd"]); c.ValorPago = Dec(r["total"]); }
                else if (s == "Atrasada") { c.QuantidadeAtrasadas = Int(r["qtd"]); c.ValorAtrasado = Dec(r["total"]); }
                else { c.QuantidadePendentes = Int(r["qtd"]); c.ValorPendente = Dec(r["total"]); }
            }
            return c;
        }

        // ======================= API 2 =======================
        private static SqlParameter[] ParamsAno(int ano)
        {
            return new SqlParameter[]
            {
                ParamData("ini", new DateTime(ano, 1, 1)),
                ParamData("fim", new DateTime(ano + 1, 1, 1))
            };
        }

        public DataTable VendasPorMes(int ano)
        {
            string sql = @"SELECT MONTH(v.data_venda) AS mes, COUNT(*) AS qtd, ISNULL(SUM(v.valor_venda - v.desconto), 0) AS liquido
                           FROM Venda v WHERE" + FiltroPeriodo + @"
                           GROUP BY MONTH(v.data_venda)";
            return HelperDAO.ExecutaSelect(sql, ParamsAno(ano));
        }

        public DataTable RankingVendedores(int ano)
        {
            string sql = @"SELECT v.funcionario_id, ISNULL(p.nome, 'Funcionário #' + CAST(v.funcionario_id AS varchar(10))) AS nome,
                                  COUNT(*) AS qtd, ISNULL(SUM(v.valor_venda - v.desconto), 0) AS liquido
                           FROM Venda v LEFT JOIN Pessoa p ON p.id = v.funcionario_id
                           WHERE" + FiltroPeriodo + @"
                           GROUP BY v.funcionario_id, p.nome
                           ORDER BY liquido DESC";
            return HelperDAO.ExecutaSelect(sql, ParamsAno(ano));
        }

        public DataTable TopMarcas(int ano, int limite)
        {
            string sql = @"SELECT TOP (@limite) c.marca, COUNT(*) AS qtd, ISNULL(SUM(v.valor_venda - v.desconto), 0) AS liquido
                           FROM Venda v INNER JOIN Carro c ON c.id = v.carro_id
                           WHERE" + FiltroPeriodo + @"
                           GROUP BY c.marca
                           ORDER BY qtd DESC, liquido DESC";
            var p = new List<SqlParameter>(ParamsAno(ano));
            p.Add(new SqlParameter("limite", limite));
            return HelperDAO.ExecutaSelect(sql, p.ToArray());
        }
    }
}
