﻿using AutoGestao.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace AutoGestao.DAO
{
    public class UsuarioDAO : PadraoDAO<UsuarioViewModel>
    {
        protected override void SetTabela()
        {
            Tabela = "Usuario";
            ChaveIdentity = true;
        }

        protected override SqlParameter[] CriaParametros(UsuarioViewModel model)
        {
            return new SqlParameter[]
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("funcionario_id", (object)(model.FuncionarioId > 0 ? model.FuncionarioId : (int?)null) ?? DBNull.Value),
                new SqlParameter("login", (object)model.Login ?? DBNull.Value),
                new SqlParameter("senha_hash", (object)model.SenhaHash ?? DBNull.Value),
                new SqlParameter("perfil", (object)model.Perfil ?? "Funcionario"),
                new SqlParameter("ativo", model.Ativo)
            };
        }

        protected override UsuarioViewModel MontaModel(DataRow r)
        {
            return new UsuarioViewModel
            {
                Id = Convert.ToInt32(r["id"]),
                FuncionarioId = r["funcionario_id"] == DBNull.Value ? 0 : Convert.ToInt32(r["funcionario_id"]),
                ClienteId = r.Table.Columns.Contains("cliente_id") && r["cliente_id"] != DBNull.Value ? Convert.ToInt32(r["cliente_id"]) : (int?)null,
                Login = r["login"].ToString(),
                SenhaHash = r["senha_hash"].ToString(),
                Perfil = r["perfil"].ToString(),
                Ativo = Convert.ToBoolean(r["ativo"]),
                DataCriacao = r["data_criacao"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(r["data_criacao"])
            };
        }

        public UsuarioViewModel Autenticar(string login, string senha)
        {
            string sql = "SELECT * FROM Usuario WHERE login = @login AND senha_hash = @senha AND ativo = 1 AND perfil IN ('Administrador', 'Funcionario')";
            var p = new SqlParameter[]
            {
                new SqlParameter("@login", login ?? ""),
                new SqlParameter("@senha", senha ?? "")
            };

            using (SqlConnection conexao = ConexaoBD.GetConexao())
            {
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddRange(p);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        DataTable tabela = new DataTable();
                        adapter.Fill(tabela);
                        if (tabela.Rows.Count == 0)
                            return null;
                        return MontaModel(tabela.Rows[0]);
                    }
                }
            }
        }

        public bool ExisteLogin(string login)
        {
            string sql = "SELECT COUNT(*) FROM Usuario WHERE login = @login";
            var p = new SqlParameter[]
            {
                new SqlParameter("@login", login ?? "")
            };

            using (SqlConnection conexao = ConexaoBD.GetConexao())
            {
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddRange(p);
                    int qtd = Convert.ToInt32(comando.ExecuteScalar());
                    return qtd > 0;
                }
            }
        }

        public UsuarioViewModel AutenticarCliente(string identificador, string senha)
        {
            string sql = @"SELECT TOP 1 u.* FROM Usuario u
                           INNER JOIN Pessoa p ON p.id = u.cliente_id
                           WHERE (u.login = @identificador OR p.cpf = @identificador)
                             AND u.senha_hash = @senha AND u.ativo = 1 AND u.perfil = 'Cliente'
                             AND p.tipo_pessoa = 'Cliente'";
            var parametros = new SqlParameter[] {
                new SqlParameter("@identificador", identificador ?? ""),
                new SqlParameter("@senha", senha ?? "")
            };
            using (SqlConnection conexao = ConexaoBD.GetConexao())
            using (SqlCommand comando = new SqlCommand(sql, conexao))
            {
                comando.Parameters.AddRange(parametros);
                using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                {
                    DataTable tabela = new DataTable(); adapter.Fill(tabela);
                    return tabela.Rows.Count == 0 ? null : MontaModel(tabela.Rows[0]);
                }
            }
        }

        public int BuscarClientePorCpf(string cpf)
        {
            string sql = "SELECT TOP 1 id FROM Pessoa WHERE cpf = @cpf AND tipo_pessoa = 'Cliente'";
            using (SqlConnection conexao = ConexaoBD.GetConexao())
            using (SqlCommand comando = new SqlCommand(sql, conexao))
            {
                comando.Parameters.AddWithValue("@cpf", cpf ?? "");
                object resultado = comando.ExecuteScalar();
                return resultado == null || resultado == DBNull.Value ? 0 : Convert.ToInt32(resultado);
            }
        }

        public bool CpfPertenceAOutraPessoa(string documento)
        {
            string sql = "SELECT COUNT(*) FROM Pessoa WHERE cpf = @cpf AND tipo_pessoa <> 'Cliente'";
            using (SqlConnection conexao = ConexaoBD.GetConexao())
            using (SqlCommand comando = new SqlCommand(sql, conexao))
            {
                comando.Parameters.AddWithValue("@cpf", documento ?? "");
                return Convert.ToInt32(comando.ExecuteScalar()) > 0;
            }
        }

        public bool ClienteJaPossuiUsuario(int clienteId)
        {
            string sql = "SELECT COUNT(*) FROM Usuario WHERE cliente_id = @clienteId";
            using (SqlConnection conexao = ConexaoBD.GetConexao())
            using (SqlCommand comando = new SqlCommand(sql, conexao))
            {
                comando.Parameters.AddWithValue("@clienteId", clienteId);
                return Convert.ToInt32(comando.ExecuteScalar()) > 0;
            }
        }

        public void CadastrarAcessoCliente(int clienteId, string login, string senha)
        {
            string sql = @"INSERT INTO Usuario (funcionario_id, cliente_id, login, senha_hash, perfil, ativo)
                           VALUES (NULL, @clienteId, @login, @senha, 'Cliente', 1)";
            using (SqlConnection conexao = ConexaoBD.GetConexao())
            using (SqlCommand comando = new SqlCommand(sql, conexao))
            {
                comando.Parameters.AddWithValue("@clienteId", clienteId);
                comando.Parameters.AddWithValue("@login", login);
                comando.Parameters.AddWithValue("@senha", senha);
                comando.ExecuteNonQuery();
            }
        }

        public List<FuncionarioViewModel> ListarFuncionariosSemUsuario()
        {
            string sql = @"
                SELECT p.*
                FROM Pessoa p
                WHERE p.tipo_pessoa = 'Funcionario'
                  AND NOT EXISTS (SELECT 1 FROM Usuario u WHERE u.funcionario_id = p.id)
                ORDER BY p.nome";

            List<FuncionarioViewModel> lista = new List<FuncionarioViewModel>();
            using (SqlConnection conexao = ConexaoBD.GetConexao())
            {
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        DataTable tabela = new DataTable();
                        adapter.Fill(tabela);
                        foreach (DataRow r in tabela.Rows)
                        {
                            lista.Add(new FuncionarioViewModel
                            {
                                Id = Convert.ToInt32(r["id"]),
                                TipoPessoa = r["tipo_pessoa"].ToString(),
                                Nome = r["nome"].ToString(),
                                Cpf = r["cpf"].ToString(),
                                Cargo = r["cargo"] == DBNull.Value ? "" : r["cargo"].ToString(),
                                StatusFuncionario = r["status_funcionario"] != DBNull.Value && Convert.ToBoolean(r["status_funcionario"])
                            });
                        }
                    }
                }
            }
            return lista;
        }
    }
}
