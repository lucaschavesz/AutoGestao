﻿using AutoGestao.Models;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace AutoGestao.DAO
{
    public class ClienteDAO : PadraoDAO<ClienteViewModel>
    {
        protected override void SetTabela()
        {
            Tabela = "Pessoa";
            NomeSpListagem = "spListagemClientes";
        }

        public override int Insert(ClienteViewModel model)
        {
            return HelperDAO.ExecutaProc("spInsert_Pessoa_Cliente", CriaParametros(model), ChaveIdentity);
        }

        public override void Update(ClienteViewModel model)
        {
            HelperDAO.ExecutaProc("spUpdate_Pessoa_Cliente", CriaParametros(model), false);
        }

        protected override SqlParameter[] CriaParametros(ClienteViewModel model)
        {
            return new SqlParameter[]
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("nome", (object)model.Nome ?? DBNull.Value),
                new SqlParameter("cpf", (object)model.Cpf ?? DBNull.Value),
                new SqlParameter("telefone", (object)model.Telefone ?? DBNull.Value),
                new SqlParameter("email", (object)model.Email ?? DBNull.Value),
                new SqlParameter("data_nascimento", model.DataNascimento),
                new SqlParameter("cep", (object)model.Cep ?? DBNull.Value),
                new SqlParameter("rua", (object)model.Rua ?? DBNull.Value),
                new SqlParameter("bairro", (object)model.Bairro ?? DBNull.Value),
                new SqlParameter("cidade", (object)model.Cidade ?? DBNull.Value),
                new SqlParameter("data_cadastro", model.DataCadastro == DateTime.MinValue ? DateTime.Now : model.DataCadastro)
            };
        }

        protected override ClienteViewModel MontaModel(DataRow r)
        {
            return new ClienteViewModel
            {
                Id = Convert.ToInt32(r["id"]),
                TipoPessoa = r["tipo_pessoa"].ToString(),
                Nome = r["nome"].ToString(),
                Cpf = r["cpf"].ToString(),
                Telefone = r["telefone"] == DBNull.Value ? "" : r["telefone"].ToString(),
                Email = r["email"] == DBNull.Value ? "" : r["email"].ToString(),
                DataNascimento = r["data_nascimento"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(r["data_nascimento"]),
                Cep = r["cep"] == DBNull.Value ? "" : r["cep"].ToString(),
                Rua = r["rua"] == DBNull.Value ? "" : r["rua"].ToString(),
                Bairro = r["bairro"] == DBNull.Value ? "" : r["bairro"].ToString(),
                Cidade = r["cidade"] == DBNull.Value ? "" : r["cidade"].ToString(),
                DataCadastro = r["data_cadastro"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(r["data_cadastro"])
            };
        }

        public List<ClienteViewModel> ConsultaAvancada(
            string nome, string cpf, string cidade, string telefone,
            DateTime? dataInicial, DateTime? dataFinal)
        {
            // O LEFT JOIN mantém clientes sem vendas na consulta e agrega as vendas por cliente.
            string sql = @"
                SELECT
                    p.id,
                    p.tipo_pessoa,
                    p.nome,
                    p.cpf,
                    p.telefone,
                    p.email,
                    p.data_nascimento,
                    p.cep,
                    p.rua,
                    p.bairro,
                    p.cidade,
                    p.data_cadastro,
                    ISNULL(v.quantidade_vendas, 0) AS quantidade_vendas,
                    v.ultima_venda
                FROM Pessoa p
                LEFT JOIN
                (
                    SELECT cliente_id,
                           COUNT(*) AS quantidade_vendas,
                           MAX(data_venda) AS ultima_venda
                    FROM Venda
                    GROUP BY cliente_id
                ) v ON v.cliente_id = p.id
                WHERE p.tipo_pessoa = 'Cliente'
                  AND (@nome = '' OR p.nome LIKE '%' + @nome + '%')
                  AND (@cpf = '' OR p.cpf LIKE '%' + @cpf + '%')
                  AND (@cidade = '' OR p.cidade LIKE '%' + @cidade + '%')
                  AND (@telefone = '' OR p.telefone LIKE '%' + @telefone + '%')
                  AND (@dataInicial IS NULL OR p.data_cadastro >= @dataInicial)
                  AND (@dataFinal IS NULL OR p.data_cadastro < DATEADD(DAY, 1, @dataFinal))
                ORDER BY p.nome";

            var parametros = new SqlParameter[]
            {
                new SqlParameter("@nome", SqlDbType.VarChar, 150) { Value = (object)(nome ?? string.Empty) },
                new SqlParameter("@cpf", SqlDbType.VarChar, 20) { Value = (object)(cpf ?? string.Empty) },
                new SqlParameter("@cidade", SqlDbType.VarChar, 100) { Value = (object)(cidade ?? string.Empty) },
                new SqlParameter("@telefone", SqlDbType.VarChar, 30) { Value = (object)(telefone ?? string.Empty) },
                new SqlParameter("@dataInicial", SqlDbType.Date) { Value = (object)dataInicial ?? DBNull.Value },
                new SqlParameter("@dataFinal", SqlDbType.Date) { Value = (object)dataFinal ?? DBNull.Value }
            };

            var tabela = HelperDAO.ExecutaSelect(sql, parametros);
            var lista = new System.Collections.Generic.List<ClienteViewModel>();
            foreach (DataRow registro in tabela.Rows)
            {
                var cliente = MontaModel(registro);
                cliente.QuantidadeVendas = Convert.ToInt32(registro["quantidade_vendas"]);
                cliente.UltimaVenda = registro["ultima_venda"] == DBNull.Value
                    ? (DateTime?)null
                    : Convert.ToDateTime(registro["ultima_venda"]);
                lista.Add(cliente);
            }
            return lista;
        }

    }
}
