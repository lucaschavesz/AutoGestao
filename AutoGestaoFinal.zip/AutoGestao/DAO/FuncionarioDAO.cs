﻿using AutoGestao.Models;
using System;
using System.Data;
using System.Data.SqlClient;

namespace AutoGestao.DAO
{
    public class FuncionarioDAO : PadraoDAO<FuncionarioViewModel>
    {
        protected override void SetTabela()
        {
            Tabela = "Pessoa";
            NomeSpListagem = "spListagemFuncionarios";
        }

        public override int Insert(FuncionarioViewModel model)
        {
            return HelperDAO.ExecutaProc("spInsert_Pessoa_Funcionario", CriaParametros(model), ChaveIdentity);
        }

        public override void Update(FuncionarioViewModel model)
        {
            HelperDAO.ExecutaProc("spUpdate_Pessoa_Funcionario", CriaParametros(model), false);
        }

        protected override SqlParameter[] CriaParametros(FuncionarioViewModel model)
        {
            return new SqlParameter[]
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("nome", (object)model.Nome ?? DBNull.Value),
                new SqlParameter("cpf", (object)model.Cpf ?? DBNull.Value),
                new SqlParameter("telefone", (object)model.Telefone ?? DBNull.Value),
                new SqlParameter("email", (object)model.Email ?? DBNull.Value),
                new SqlParameter("data_nascimento", model.DataNascimento == DateTime.MinValue ? (object)DBNull.Value : model.DataNascimento),
                new SqlParameter("cep", (object)model.Cep ?? DBNull.Value),
                new SqlParameter("rua", (object)model.Rua ?? DBNull.Value),
                new SqlParameter("bairro", (object)model.Bairro ?? DBNull.Value),
                new SqlParameter("cidade", (object)model.Cidade ?? DBNull.Value),
                new SqlParameter("cargo", (object)model.Cargo ?? DBNull.Value),
                new SqlParameter("salario", model.Salario.HasValue ? (object)model.Salario.Value : DBNull.Value),
                new SqlParameter("data_contratacao", model.DataContratacao == DateTime.MinValue ? DateTime.Today : model.DataContratacao),
                new SqlParameter("status_funcionario", model.StatusFuncionario)
            };
        }

        protected override FuncionarioViewModel MontaModel(DataRow r)
        {
            return new FuncionarioViewModel
            {
                Id = Convert.ToInt32(r["id"]),
                TipoPessoa = r["tipo_pessoa"].ToString(),
                Nome = r["nome"].ToString(),
                Cpf = r["cpf"].ToString(),
                Telefone = r["telefone"] == DBNull.Value ? "" : r["telefone"].ToString(),
                Email = r["email"] == DBNull.Value ? "" : r["email"].ToString(),
                DataNascimento = r["data_nascimento"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(r["data_nascimento"]),
                Cep = r["cep"] == DBNull.Value ? "" : r["cep"].ToString(),
                Rua = r["rua"] == DBNull.Value ? "" : r["rua"].ToString(),
                Bairro = r["bairro"] == DBNull.Value ? "" : r["bairro"].ToString(),
                Cidade = r["cidade"] == DBNull.Value ? "" : r["cidade"].ToString(),
                Cargo = r["cargo"] == DBNull.Value ? "" : r["cargo"].ToString(),
                Salario = r["salario"] == DBNull.Value ? (decimal?)null : Convert.ToDecimal(r["salario"]),
                DataContratacao = r["data_contratacao"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(r["data_contratacao"]),
                StatusFuncionario = r["status_funcionario"] != DBNull.Value && Convert.ToBoolean(r["status_funcionario"])
            };
        }
    }
}
