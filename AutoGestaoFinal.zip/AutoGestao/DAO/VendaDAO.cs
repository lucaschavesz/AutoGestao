﻿using AutoGestao.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace AutoGestao.DAO
{
    public class VendaDAO : PadraoDAO<VendaViewModel>
    {
        protected override void SetTabela()
        {
            Tabela = "Venda";
            ChaveIdentity = true;
        }

        protected override SqlParameter[] CriaParametros(VendaViewModel model)
        {
            return new SqlParameter[]
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("cliente_id", model.ClienteId),
                new SqlParameter("funcionario_id", model.FuncionarioId),
                new SqlParameter("carro_id", model.CarroId),
                new SqlParameter("data_venda", model.DataVenda == DateTime.MinValue ? DateTime.Now : model.DataVenda),
                new SqlParameter("valor_venda", model.ValorVenda),
                new SqlParameter("desconto", model.Desconto),
                new SqlParameter("forma_pagamento", model.FormaPagamento),
                new SqlParameter("qtd_parcelas", model.QtdParcelas),
                new SqlParameter("valor_entrada", model.ValorEntrada),
                new SqlParameter("status", string.IsNullOrEmpty(model.Status) ? "Concluida" : model.Status)
            };
        }

        protected override VendaViewModel MontaModel(DataRow r)
        {
            var v = new VendaViewModel
            {
                Id = Convert.ToInt32(r["id"]),
                ClienteId = Convert.ToInt32(r["cliente_id"]),
                FuncionarioId = Convert.ToInt32(r["funcionario_id"]),
                CarroId = Convert.ToInt32(r["carro_id"]),
                DataVenda = Convert.ToDateTime(r["data_venda"]),
                ValorVenda = Convert.ToDecimal(r["valor_venda"]),
                Desconto = Convert.ToDecimal(r["desconto"]),
                FormaPagamento = r["forma_pagamento"].ToString(),
                QtdParcelas = Convert.ToInt32(r["qtd_parcelas"]),
                ValorEntrada = Convert.ToDecimal(r["valor_entrada"]),
                Status = r["status"].ToString()
            };

            if (r.Table.Columns.Contains("cliente_nome") && r["cliente_nome"] != DBNull.Value)
                v.ClienteNome = r["cliente_nome"].ToString();
            if (r.Table.Columns.Contains("funcionario_nome") && r["funcionario_nome"] != DBNull.Value)
                v.FuncionarioNome = r["funcionario_nome"].ToString();
            if (r.Table.Columns.Contains("carro_modelo") && r["carro_modelo"] != DBNull.Value)
                v.CarroDescricao = $"{r["carro_marca"]} {r["carro_modelo"]} ({r["carro_ano"]})";

            return v;
        }

        // Listagem com nomes (cliente, vendedor, veículo) via JOIN, mais recentes primeiro
        public override List<VendaViewModel> Listagem()
        {
            string sql = @"SELECT v.*, c.nome AS cliente_nome, f.nome AS funcionario_nome,
                                  ca.marca AS carro_marca, ca.modelo AS carro_modelo, ca.ano AS carro_ano
                           FROM Venda v
                           LEFT JOIN Pessoa c ON c.id = v.cliente_id
                           LEFT JOIN Pessoa f ON f.id = v.funcionario_id
                           LEFT JOIN Carro ca ON ca.id = v.carro_id
                           ORDER BY v.data_venda DESC, v.id DESC";
            var tabela = HelperDAO.ExecutaSelect(sql, null);
            List<VendaViewModel> lista = new List<VendaViewModel>();
            foreach (DataRow r in tabela.Rows)
                lista.Add(MontaModel(r));
            return lista;
        }

        public void AtualizaStatusCarro(int carroId, string status)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("carro_id", carroId),
                new SqlParameter("status", status)
            };
            HelperDAO.ExecutaProc("spAtualizaStatusCarro", p, false);
        }

        public List<VendaViewModel> ConsultaAvancada(string clienteNome, int funcionarioId, string status, DateTime dataInicial, DateTime dataFinal)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("cliente_nome", clienteNome ?? ""),
                new SqlParameter("funcionario_id", funcionarioId),
                new SqlParameter("status", status ?? ""),
                new SqlParameter("dataInicial", dataInicial),
                new SqlParameter("dataFinal", dataFinal)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spConsultaAvancadaVendas", p);
            List<VendaViewModel> lista = new List<VendaViewModel>();
            foreach (DataRow r in tabela.Rows)
                lista.Add(MontaModel(r));
            return lista;
        }
    }
}
