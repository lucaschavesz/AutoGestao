﻿using AutoGestao.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace AutoGestao.DAO
{
    public class CarroDAO : PadraoDAO<CarroViewModel>
    {
        protected override void SetTabela()
        {
            Tabela = "Carro";
            NomeSpListagem = "spListagemCarros";
            ChaveIdentity = true;
        }

        protected override SqlParameter[] CriaParametros(CarroViewModel model)
        {
            return new SqlParameter[]
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("marca", model.Marca),
                new SqlParameter("modelo", model.Modelo),
                new SqlParameter("ano", model.Ano),
                new SqlParameter("versao", (object)model.Versao ?? DBNull.Value),
                new SqlParameter("quilometragem", model.Quilometragem),
                new SqlParameter("cambio", (object)model.Cambio ?? DBNull.Value),
                new SqlParameter("combustivel", (object)model.Combustivel ?? DBNull.Value),
                new SqlParameter("motorizacao", (object)model.Motorizacao ?? DBNull.Value),
                new SqlParameter("potencia", (object)model.Potencia ?? DBNull.Value),
                new SqlParameter("codigo_marca_fipe", (object)model.CodigoMarcaFipe ?? DBNull.Value),
                new SqlParameter("codigo_modelo_fipe", (object)model.CodigoModeloFipe ?? DBNull.Value),
                new SqlParameter("codigo_ano_fipe", (object)model.CodigoAnoFipe ?? DBNull.Value),
                new SqlParameter("codigo_fipe", (object)model.CodigoFipe ?? DBNull.Value),
                new SqlParameter("valor_fipe", model.ValorFipe.HasValue ? (object)model.ValorFipe.Value : DBNull.Value),
                new SqlParameter("mes_referencia_fipe", (object)model.MesReferenciaFipe ?? DBNull.Value),
                new SqlParameter("valor_venda", model.ValorVenda),
                new SqlParameter("documentacao", model.Documentacao),
                new SqlParameter("garantia_revisao", (object)model.GarantiaRevisao ?? DBNull.Value),
                new SqlParameter("leilao", model.Leilao),
                new SqlParameter("status", string.IsNullOrEmpty(model.Status) ? "Disponivel" : model.Status),
                new SqlParameter("data_cadastro", model.DataCadastro == DateTime.MinValue ? DateTime.Now : model.DataCadastro)
            };
        }

        protected override CarroViewModel MontaModel(DataRow r)
        {
            var c = new CarroViewModel
            {
                Id = Convert.ToInt32(r["id"]),
                Marca = r["marca"].ToString(),
                Modelo = r["modelo"].ToString(),
                Ano = Convert.ToInt32(r["ano"]),
                Versao = r["versao"] == DBNull.Value ? "" : r["versao"].ToString(),
                Quilometragem = Convert.ToInt32(r["quilometragem"]),
                Cambio = r["cambio"] == DBNull.Value ? "" : r["cambio"].ToString(),
                Combustivel = r["combustivel"] == DBNull.Value ? "" : r["combustivel"].ToString(),
                Motorizacao = r["motorizacao"] == DBNull.Value ? "" : r["motorizacao"].ToString(),
                Potencia = r["potencia"] == DBNull.Value ? "" : r["potencia"].ToString(),
                CodigoMarcaFipe = r["codigo_marca_fipe"] == DBNull.Value ? "" : r["codigo_marca_fipe"].ToString(),
                CodigoModeloFipe = r["codigo_modelo_fipe"] == DBNull.Value ? "" : r["codigo_modelo_fipe"].ToString(),
                CodigoAnoFipe = r["codigo_ano_fipe"] == DBNull.Value ? "" : r["codigo_ano_fipe"].ToString(),
                CodigoFipe = r["codigo_fipe"] == DBNull.Value ? "" : r["codigo_fipe"].ToString(),
                ValorFipe = r["valor_fipe"] == DBNull.Value ? (decimal?)null : Convert.ToDecimal(r["valor_fipe"]),
                MesReferenciaFipe = r["mes_referencia_fipe"] == DBNull.Value ? "" : r["mes_referencia_fipe"].ToString(),
                ValorVenda = Convert.ToDecimal(r["valor_venda"]),
                Documentacao = Convert.ToBoolean(r["documentacao"]),
                GarantiaRevisao = r["garantia_revisao"] == DBNull.Value ? "" : r["garantia_revisao"].ToString(),
                Leilao = Convert.ToBoolean(r["leilao"]),
                Status = r["status"].ToString(),
                DataCadastro = Convert.ToDateTime(r["data_cadastro"])
            };

            if (r.Table.Columns.Contains("foto_principal_caminho") && r["foto_principal_caminho"] != DBNull.Value)
                c.FotoPrincipalCaminho = r["foto_principal_caminho"].ToString();

            return c;
        }

        public List<CarroViewModel> ConsultaAvancada(string modelo, string marca, string status, DateTime dataInicial, DateTime dataFinal)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("modelo", modelo ?? ""),
                new SqlParameter("marca", marca ?? ""),
                new SqlParameter("status", status ?? ""),
                new SqlParameter("dataInicial", dataInicial),
                new SqlParameter("dataFinal", dataFinal)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spConsultaAvancadaCarros", p);
            List<CarroViewModel> lista = new List<CarroViewModel>();
            foreach (DataRow r in tabela.Rows)
                lista.Add(MontaModel(r));
            return lista;
        }

        public override List<CarroViewModel> Listagem()
        {
            var tabela = HelperDAO.ExecutaProcSelect("spListagemCarros", null);
            List<CarroViewModel> lista = new List<CarroViewModel>();
            foreach (DataRow registro in tabela.Rows)
                lista.Add(MontaModel(registro));
            return lista;
        }

        public List<CarroViewModel> ListagemDisponiveis()
    {
            var tabela = HelperDAO.ExecutaProcSelect("spListagemCarrosDisponiveis", null);
            List<CarroViewModel> lista = new List<CarroViewModel>();
            foreach (DataRow registro in tabela.Rows)
                lista.Add(MontaModel(registro));
            return lista;
        }
    }
}
