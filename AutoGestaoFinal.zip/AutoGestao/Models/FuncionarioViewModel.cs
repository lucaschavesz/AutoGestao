﻿using System;

namespace AutoGestao.Models
{
    public class FuncionarioViewModel : PessoaViewModel
    {
        public string Cargo { get; set; }
        public decimal? Salario { get; set; }
        public DateTime DataContratacao { get; set; }
        public bool StatusFuncionario { get; set; }
    }
}
