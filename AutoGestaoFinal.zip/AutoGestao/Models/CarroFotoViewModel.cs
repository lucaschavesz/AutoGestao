﻿namespace AutoGestao.Models
{
    public class CarroFotoViewModel : PadraoViewModel
    {
        public int CarroId { get; set; }
        public string CaminhoImagem { get; set; }
        public bool FotoPrincipal { get; set; }
    }
}
