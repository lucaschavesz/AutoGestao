﻿using System;

namespace AutoGestao.Models
{
    public class ParcelaViewModel : PadraoViewModel
    {
        public int VendaId { get; set; }
        public int NumeroParcela { get; set; }
        public decimal Valor { get; set; }
        public DateTime DataVencimento { get; set; }
        public DateTime? DataPagamento { get; set; }
        public string Status { get; set; }
        public string ClienteNome { get; set; }
    }
}
