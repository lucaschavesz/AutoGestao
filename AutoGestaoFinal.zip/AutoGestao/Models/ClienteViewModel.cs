﻿using System;

namespace AutoGestao.Models
{
    public class ClienteViewModel : PessoaViewModel
    {
        public DateTime DataCadastro { get; set; }

        // Campos complementares preenchidos pela consulta avançada (JOIN com Venda).
        public int QuantidadeVendas { get; set; }
        public DateTime? UltimaVenda { get; set; }
    }
}
