﻿using System;

namespace AutoGestao.Models
{
    public class UsuarioViewModel : PadraoViewModel
    {
        public int FuncionarioId { get; set; }
        public int? ClienteId { get; set; }
        public string Login { get; set; }
        public string SenhaHash { get; set; }
        public string Perfil { get; set; }
        public bool Ativo { get; set; }
        public DateTime DataCriacao { get; set; }
        public string FuncionarioNome { get; set; }
    }
}
