﻿using System;

namespace AutoGestao.Models
{
    public abstract class PessoaViewModel : PadraoViewModel
    {
        public string TipoPessoa { get; set; }
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public string Telefone { get; set; }
        public string Email { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Cep { get; set; }
        public string Rua { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
    }
}
