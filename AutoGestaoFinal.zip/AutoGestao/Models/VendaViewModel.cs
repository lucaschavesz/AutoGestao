﻿using System;

namespace AutoGestao.Models
{
    public class VendaViewModel : PadraoViewModel
    {
        public int ClienteId { get; set; }
        public int FuncionarioId { get; set; }
        public int CarroId { get; set; }
        public DateTime DataVenda { get; set; }
        public decimal ValorVenda { get; set; }
        public decimal Desconto { get; set; }
        public string FormaPagamento { get; set; }
        public int QtdParcelas { get; set; }
        public decimal ValorEntrada { get; set; }
        public string Status { get; set; }

        // Campos preenchidos via JOIN para listagens/consultas
        public string ClienteNome { get; set; }
        public string FuncionarioNome { get; set; }
        public string CarroDescricao { get; set; }
    }
}
