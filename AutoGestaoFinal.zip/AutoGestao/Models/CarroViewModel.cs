﻿using System;
using System.Collections.Generic;

namespace AutoGestao.Models
{
    public class CarroViewModel : PadraoViewModel
    {
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int Ano { get; set; }
        public string Versao { get; set; }
        public int Quilometragem { get; set; }
        public string Cambio { get; set; }
        public string Combustivel { get; set; }
        public string Motorizacao { get; set; }
        public string Potencia { get; set; }
        public string CodigoMarcaFipe { get; set; }
        public string CodigoModeloFipe { get; set; }
        public string CodigoAnoFipe { get; set; }
        public string CodigoFipe { get; set; }
        public decimal? ValorFipe { get; set; }
        public string MesReferenciaFipe { get; set; }
        public decimal ValorVenda { get; set; }
        public bool Documentacao { get; set; }
        public string GarantiaRevisao { get; set; }
        public bool Leilao { get; set; }
        public string Status { get; set; }
        public DateTime DataCadastro { get; set; }
        public string FotoPrincipalCaminho { get; set; }
        public List<string> Fotos { get; set; } = new List<string>();
    }
}
