using System;
using System.Collections.Generic;

namespace AutoGestao.Models.Api
{
    // ---------- API 1: GET /api/relatorios/resumo-vendas ----------
    public class ResumoVendasResponse
    {
        public PeriodoDto Periodo { get; set; }
        public TotaisVendasDto Vendas { get; set; }
        public List<FormaPagamentoDto> PorFormaPagamento { get; set; } = new List<FormaPagamentoDto>();
        public EstoqueDto Estoque { get; set; }
        public CarteiraParcelasDto Parcelas { get; set; }
    }

    public class PeriodoDto
    {
        public DateTime? DataInicial { get; set; }
        public DateTime? DataFinal { get; set; }
    }

    public class TotaisVendasDto
    {
        public int Quantidade { get; set; }
        public decimal FaturamentoBruto { get; set; }
        public decimal TotalDescontos { get; set; }
        public decimal FaturamentoLiquido { get; set; }
        public decimal TotalEntradas { get; set; }
        public decimal TicketMedio { get; set; }
        public decimal DescontoMedioPercentual { get; set; }
    }

    public class FormaPagamentoDto
    {
        public string FormaPagamento { get; set; }
        public int Quantidade { get; set; }
        public decimal ValorLiquido { get; set; }
        public decimal Percentual { get; set; }
    }

    public class EstoqueDto
    {
        public int Disponivel { get; set; }
        public int Reservado { get; set; }
        public int Vendido { get; set; }
        public int Total { get; set; }
        public decimal ValorEmEstoque { get; set; }   // soma do valor de venda dos veículos disponíveis
    }

    public class CarteiraParcelasDto
    {
        public int QuantidadePendentes { get; set; }
        public decimal ValorPendente { get; set; }
        public int QuantidadeAtrasadas { get; set; }
        public decimal ValorAtrasado { get; set; }
        public int QuantidadePagas { get; set; }
        public decimal ValorPago { get; set; }
    }

    // ---------- API 2: GET /api/relatorios/desempenho ----------
    public class DesempenhoResponse
    {
        public int Ano { get; set; }
        public int TotalVendasAno { get; set; }
        public decimal FaturamentoLiquidoAno { get; set; }
        public MelhorMesDto MelhorMes { get; set; }
        public List<VendaMensalDto> PorMes { get; set; } = new List<VendaMensalDto>();
        public List<RankingVendedorDto> RankingVendedores { get; set; } = new List<RankingVendedorDto>();
        public List<RankingMarcaDto> TopMarcas { get; set; } = new List<RankingMarcaDto>();
    }

    public class MelhorMesDto
    {
        public int Mes { get; set; }
        public string NomeMes { get; set; }
        public decimal FaturamentoLiquido { get; set; }
    }

    public class VendaMensalDto
    {
        public int Mes { get; set; }
        public string NomeMes { get; set; }
        public int Quantidade { get; set; }
        public decimal FaturamentoLiquido { get; set; }
        public decimal TicketMedio { get; set; }
    }

    public class RankingVendedorDto
    {
        public int Posicao { get; set; }
        public int FuncionarioId { get; set; }
        public string Nome { get; set; }
        public int Quantidade { get; set; }
        public decimal FaturamentoLiquido { get; set; }
        public decimal ParticipacaoPercentual { get; set; }
    }

    public class RankingMarcaDto
    {
        public string Marca { get; set; }
        public int Quantidade { get; set; }
        public decimal FaturamentoLiquido { get; set; }
    }
}
