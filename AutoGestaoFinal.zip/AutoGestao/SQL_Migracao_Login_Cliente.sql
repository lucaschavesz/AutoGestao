/*
    AutoGestão - suporte a contas de clientes
    Execute no banco de dados do AutoGestão antes de utilizar o cadastro público.

    Pré-requisito: tabela dbo.Usuario e tabela dbo.Pessoa já existentes.
    A coluna Usuario.funcionario_id passa a aceitar NULL para contas de clientes.
    Cada usuário continuará vinculado a apenas um funcionário ou cliente.
*/

IF COL_LENGTH('dbo.Usuario', 'cliente_id') IS NULL
BEGIN
    ALTER TABLE dbo.Usuario ADD cliente_id INT NULL;
END;
GO

-- Contas de cliente não possuem funcionario_id.
IF EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('dbo.Usuario')
      AND name = 'funcionario_id' AND is_nullable = 0
)
BEGIN
    ALTER TABLE dbo.Usuario ALTER COLUMN funcionario_id INT NULL;
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Usuario_Pessoa_Cliente'
)
BEGIN
    ALTER TABLE dbo.Usuario WITH CHECK
    ADD CONSTRAINT FK_Usuario_Pessoa_Cliente
        FOREIGN KEY (cliente_id) REFERENCES dbo.Pessoa(id);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Usuario_Vinculo_Perfil'
)
BEGIN
    ALTER TABLE dbo.Usuario WITH CHECK
    ADD CONSTRAINT CK_Usuario_Vinculo_Perfil CHECK
    (
        (perfil IN ('Administrador', 'Funcionario') AND funcionario_id IS NOT NULL AND cliente_id IS NULL)
        OR
        (perfil = 'Cliente' AND cliente_id IS NOT NULL AND funcionario_id IS NULL)
    );
END;
GO

-- Impede que um mesmo cadastro de cliente receba duas contas de acesso.
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes WHERE name = 'UX_Usuario_ClienteId'
      AND object_id = OBJECT_ID('dbo.Usuario')
)
BEGIN
    CREATE UNIQUE INDEX UX_Usuario_ClienteId
        ON dbo.Usuario(cliente_id)
        WHERE cliente_id IS NOT NULL;
END;
GO
